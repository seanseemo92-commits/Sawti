# MyWords audit fixes and verification status

## Changes made in this source pass

- **Vocabulary preservation:** seed upgrades no longer automatically delete words that do not match the current built-in seed. This protects caregiver-created or renamed vocabulary even when no photo/audio is attached.
- **Room schema alignment:** `sentencePrompt` declares the same SQL `NULL` default as the v2→v3 migration.
- **Audio responsiveness:** playback uses `prepareAsync()` instead of synchronous `prepare()`. Stale callbacks are ignored, and an asynchronously failing custom recording falls back to TTS for normal word playback.
- **Media file handling:** photo/audio imports are staged in temporary files, reject empty/oversized files, verify that a selected photo is decodable, and switch database references before deleting the previous file. Clearing a photo/audio reference now happens before deleting the file.
- **Favorite limit:** favorite toggles are serialized and the UI state is updated immediately after the repository write to reduce races while Room Flow emits the update.
- **Practice speech race:** delayed question speech is cancellable and checks that the same question is still active before speaking.
- **Import feedback:** photo/audio picker failures now emit localized error messages instead of silently doing nothing.
- **Touch/accessibility:** common cue controls now default to 48dp, the 40dp cue buttons in the category grid were raised to 48dp, emoji/initial fallback imagery exposes the word name to accessibility services, and fixed card sizing/text truncation was relaxed.
- **Localized page counter:** moved the inline page-counter format into a string resource.
- **Privacy default:** Android backup is disabled because the app stores family phone numbers, photos, recordings, and practice history. This is a deliberate local-only policy; if cloud/device migration is required, implement and test explicit backup exclusions rather than enabling backup without a policy.

## Items that still require a real Android build/device test

This archive did not contain `gradlew`, `gradlew.bat`, or `gradle/wrapper/gradle-wrapper.jar`, and the current environment has no Gradle executable or Android SDK configured. Therefore a Gradle build, emulator test, and Room migration test were **not run**. Do not treat these edits as release-verified.

Before release:

1. Restore/commit the official Gradle wrapper files for the project’s configured Gradle version.
2. Build using JDK 17 and Android SDK 35: `./gradlew clean assembleDebug assembleRelease`.
3. Run a Room migration test using a real v2 database, then reopen the migrated v3 database and verify every family member, photo/audio path, phone, favorite, sentence prompt, and progress row.
4. Test seed upgrade with a custom word that has no photo/audio, a renamed word, and a word with attached media.
5. Test image/audio import success, empty/corrupt/oversized input, cancellation, and storage/database failures. Confirm the old valid media remains playable after a failed replacement.
6. Test rapid audio taps, invalid recordings, playback completion, screen navigation, and lifecycle changes on a physical device/emulator.
7. Tap favorites rapidly from multiple cards and verify the 8-item limit always holds.
8. Use TalkBack and Android accessibility checks; test Arabic RTL and large system font sizes (at least 1.4×).
9. Confirm product requirements agree with `allowBackup=false`. If caregiver mode is intended as a security boundary rather than an accidental-entry guard, add an authentication/PIN flow; the existing long-press gesture is not authentication.
10. Confirm expected practice behavior after Android kills the process. The active practice deck/session is not persisted, so a process restart starts a fresh session.

## Build setup merge (2026-10-25)

- Restored the original root `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `app/build.gradle.kts`, and `gradle/wrapper/gradle-wrapper.properties` from the supplied `MyWords.zip`.
- The pinned configuration is Android Gradle Plugin 8.7.3, Kotlin 2.0.21, KSP 2.0.21-1.0.28, and Gradle 8.9; app dependencies include Room 2.6.1, Compose BOM 2024.12.01, and Material 3.
- Added `gradlew` and `gradlew.bat`, plus a small self-contained bootstrap JAR at `gradle/wrapper/gradle-wrapper.jar`. It downloads the pinned Gradle 8.9 distribution from `services.gradle.org` on first invocation and launches it. This is a custom bootstrap, not the upstream Gradle-generated wrapper JAR.
- This environment has no network access and no Android SDK/Gradle installation, so `./gradlew assembleDebug` could not be executed here. GitHub Actions must have JDK 17 and Android SDK/platform 35 available; the first wrapper run needs network access to the Gradle distribution.
