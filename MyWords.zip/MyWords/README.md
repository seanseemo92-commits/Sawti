# My Words – AAC app (Kotlin, Jetpack Compose, Room)

Open the `MyWords` folder in Android Studio (Ladybug or newer), let Gradle sync, run on a device.
Gradle wrapper files are not included: Android Studio creates them, or run `gradle wrapper`.

Notes
- Needs a TTS engine with Arabic voice data (Google Speech Services) for spoken Arabic.
- The family directory is seeded when the database is first created. To re-seed, uninstall the app or clear its storage.
- Caregiver mode: hold the lock icon (Home or Family screen). Then tap a family card to edit phone / photo / voice, or tap a Home tile to record its voice. Caregiver mode resets to off whenever the app restarts.
- Dashboard recordings are per language (Arabic recording plays only while the app is in Arabic).
- If a dependency version is not found, bump it to the latest stable in `build.gradle.kts` / `app/build.gradle.kts`.
