package com.mywords.audio

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Loud attention chime for "come here" (separate from the spoken emergency phrase).
 * Uses the ALARM stream at full volume + repeating vibration; the previous alarm
 * volume is restored on [stop]. The ViewModel calls [beep] once per second.
 *
 * ToneGenerator tones are built into Android, so no audio asset is needed. If you
 * prefer a custom sound, drop an .ogg in res/raw and play it with SoundPool instead.
 */
class AlertChime(context: Context) {
    private val appContext = context.applicationContext
    private val audio = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var tone: ToneGenerator? = null
    private var savedVolume = -1

    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            (appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    fun start() {
        if (tone != null) return
        runCatching {
            savedVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM)
            audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        }
        tone = runCatching { ToneGenerator(AudioManager.STREAM_ALARM, 100) }.getOrNull()
        val pattern = longArrayOf(0, 600, 300)
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    fun beep() {
        tone?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 800)
    }

    fun stop() {
        tone?.release()
        tone = null
        vibrator?.cancel()
        if (savedVolume >= 0) {
            runCatching { audio.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0) }
            savedVolume = -1
        }
    }
}
