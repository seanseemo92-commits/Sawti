package com.mywords.domain.repository

import com.mywords.domain.model.Category

interface CommunicationRepository {
    fun getCategories(): List<Category>
}
