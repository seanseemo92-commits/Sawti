package com.mywords.domain.model

/** Languages the app supports. [tag] is a BCP-47 language tag. */
enum class AppLanguage(val tag: String) {
    ARABIC("ar"),
    ENGLISH("en");

    val other: AppLanguage get() = if (this == ARABIC) ENGLISH else ARABIC

    companion object {
        fun fromTag(tag: String?): AppLanguage =
            if (tag?.startsWith("ar") == true) ARABIC else ENGLISH
    }
}

/** SINGLE = selected language only. DUAL = selected language + other language as subtitle. */
enum class DisplayMode { SINGLE, DUAL }

/** A string available in both languages. */
data class LocalizedText(val ar: String, val en: String) {
    fun get(language: AppLanguage): String = if (language == AppLanguage.ARABIC) ar else en
}

/**
 * Domain-level icon keys. The domain layer stays free of Compose;
 * the presentation layer maps these to ImageVectors.
 */
enum class SymbolIcon {
    WATER, FOOD, BATHROOM, HELP, MEDICINE, SLEEP,
    HOT, COLD, TIRED, PAIN, DIZZY, BETTER,
    FAMILY, DOCTOR, NURSE,
    YES, NO, THANKS, WAIT
}

/** Drives the colour family used for a category's tiles. */
enum class CategoryTheme { NEEDS, FEELINGS, PEOPLE, RESPONSES }

/**
 * One tile.
 * [label]  – short text shown on the tile.
 * [spoken] – full sentence sent to TTS ("I need water, please").
 */
data class CommunicationItem(
    val id: String,
    val label: LocalizedText,
    val spoken: LocalizedText,
    val icon: SymbolIcon,
)

data class Category(
    val id: String,
    val title: LocalizedText,
    val theme: CategoryTheme,
    val items: List<CommunicationItem>,
)

/** Phrase spoken (repeatedly) by the emergency button. */
object EmergencyPhrase {
    val text = LocalizedText(
        ar = "أحتاج إلى مساعدة عاجلة الآن!",
        en = "I need urgent help now!",
    )
}
