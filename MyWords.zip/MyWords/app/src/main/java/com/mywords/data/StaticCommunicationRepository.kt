package com.mywords.data

import com.mywords.domain.model.Category
import com.mywords.domain.model.CategoryTheme
import com.mywords.domain.model.CommunicationItem
import com.mywords.domain.model.LocalizedText
import com.mywords.domain.model.SymbolIcon
import com.mywords.domain.repository.CommunicationRepository

/**
 * Built-in vocabulary. Swap for Room/DataStore later so caregivers can add custom phrases.
 * Arabic is Modern Standard Arabic because TTS engines pronounce it most reliably.
 * Edit the `spoken` strings if you want dialect phrasing.
 */
class StaticCommunicationRepository : CommunicationRepository {

    private fun item(
        id: String, icon: SymbolIcon,
        labelAr: String, labelEn: String,
        spokenAr: String, spokenEn: String,
    ) = CommunicationItem(id, LocalizedText(labelAr, labelEn), LocalizedText(spokenAr, spokenEn), icon)

    override fun getCategories(): List<Category> = listOf(
        Category(
            id = "needs",
            title = LocalizedText("احتياجات عاجلة", "Immediate Needs"),
            theme = CategoryTheme.NEEDS,
            items = listOf(
                item("water", SymbolIcon.WATER, "ماء", "Water", "أريد ماءً من فضلك", "I need water, please"),
                item("food", SymbolIcon.FOOD, "طعام", "Food", "أنا جائع وأريد أن آكل", "I am hungry. I want to eat"),
                item("bathroom", SymbolIcon.BATHROOM, "دورة المياه", "Bathroom", "أحتاج إلى دورة المياه", "I need the bathroom"),
                item("help", SymbolIcon.HELP, "ألم / مساعدة", "Pain / Help", "أحتاج إلى مساعدة", "I need help"),
                item("medicine", SymbolIcon.MEDICINE, "دواء", "Medicine", "أحتاج إلى دوائي", "I need my medicine"),
                item("sleep", SymbolIcon.SLEEP, "نوم", "Sleep", "أريد أن أنام", "I want to sleep"),
            ),
        ),
        Category(
            id = "feelings",
            title = LocalizedText("المشاعر والحالة الجسدية", "Feelings & Body"),
            theme = CategoryTheme.FEELINGS,
            items = listOf(
                item("hot", SymbolIcon.HOT, "حار", "Hot", "أشعر بالحر", "I feel hot"),
                item("cold", SymbolIcon.COLD, "بارد", "Cold", "أشعر بالبرد", "I feel cold"),
                item("tired", SymbolIcon.TIRED, "تعب", "Tired", "أشعر بالتعب", "I feel tired"),
                item("pain", SymbolIcon.PAIN, "أشعر بألم", "In Pain", "أشعر بألم", "I am in pain"),
                item("dizzy", SymbolIcon.DIZZY, "دوار", "Dizzy", "أشعر بالدوار", "I feel dizzy"),
                item("better", SymbolIcon.BETTER, "أفضل", "Better", "أشعر بتحسن", "I feel better"),
            ),
        ),
        Category(
            id = "people",
            title = LocalizedText("الأشخاص والمساعدة", "People & Assistance"),
            theme = CategoryTheme.PEOPLE,
            items = listOf(
                item("family", SymbolIcon.FAMILY, "اتصل بالعائلة", "Call Family", "من فضلك اتصل بعائلتي", "Please call my family"),
                item("doctor", SymbolIcon.DOCTOR, "الطبيب", "Doctor", "أريد أن أتحدث مع الطبيب", "I want to speak to the doctor"),
                item("nurse", SymbolIcon.NURSE, "الممرضة", "Nurse", "أحتاج إلى الممرضة", "I need the nurse"),
            ),
        ),
        Category(
            id = "responses",
            title = LocalizedText("ردود سريعة", "Quick Responses"),
            theme = CategoryTheme.RESPONSES,
            items = listOf(
                item("yes", SymbolIcon.YES, "نعم", "Yes", "نعم", "Yes"),
                item("no", SymbolIcon.NO, "لا", "No", "لا", "No"),
                item("thanks", SymbolIcon.THANKS, "شكرًا", "Thank You", "شكرًا لك", "Thank you"),
                item("wait", SymbolIcon.WAIT, "انتظر من فضلك", "Please Wait", "من فضلك انتظر قليلًا", "Please wait a moment"),
            ),
        ),
    )
}
