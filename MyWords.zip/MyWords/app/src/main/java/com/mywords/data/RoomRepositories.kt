package com.mywords.data

import android.content.Context
import com.mywords.data.db.FamilyDao
import com.mywords.data.db.PainDao
import com.mywords.data.db.PainReportEntity
import com.mywords.data.db.VoiceDao
import com.mywords.data.db.VoiceRecordingEntity
import com.mywords.data.db.toDomain
import com.mywords.domain.model.FamilyMember
import com.mywords.domain.model.PainRegion
import com.mywords.domain.model.PainSeverity
import com.mywords.domain.model.RecordingKeys
import com.mywords.domain.repository.FamilyRepository
import com.mywords.domain.repository.PainRepository
import com.mywords.domain.repository.VoiceRepository
import java.io.File
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class RoomVoiceRepository(private val dao: VoiceDao) : VoiceRepository {

    override fun observeRecordings(): Flow<Map<String, String>> =
        dao.observeAll().map { list -> list.associate { it.recordingKey to it.filePath } }

    override suspend fun save(key: String, file: File) {
        withContext(Dispatchers.IO) {
            val old = dao.pathFor(key)
            dao.upsert(VoiceRecordingEntity(key, file.absolutePath))
            if (old != null && old != file.absolutePath) File(old).delete()
        }
    }

    override suspend fun delete(key: String) {
        withContext(Dispatchers.IO) {
            dao.pathFor(key)?.let { File(it).delete() }
            dao.delete(key)
        }
    }
}

class RoomFamilyRepository(
    context: Context,
    private val familyDao: FamilyDao,
    private val voices: VoiceRepository,
) : FamilyRepository {

    private val filesDir = context.applicationContext.filesDir

    override fun observeMembers(): Flow<List<FamilyMember>> =
        combine(familyDao.observeAll(), voices.observeRecordings()) { members, recordings ->
            members.map { it.toDomain(recordings[RecordingKeys.family(it.id)]) }
        }

    override suspend fun updateDetails(id: Long, spokenPhrase: String, phone: String) =
        familyDao.updateDetails(id, spokenPhrase, phone)

    /** Copies the picked image into app storage so it survives even if the gallery item moves. */
    override suspend fun setPhoto(id: Long, image: InputStream) {
        withContext(Dispatchers.IO) {
            val dir = File(filesDir, "photos").apply { mkdirs() }
            val target = File(dir, "member_${id}_${System.currentTimeMillis()}.jpg")
            image.use { input -> target.outputStream().use { input.copyTo(it) } }
            val old = familyDao.photoPath(id)
            familyDao.updatePhoto(id, target.absolutePath)
            old?.let { File(it).delete() }
        }
    }

    override suspend fun clearPhoto(id: Long) {
        withContext(Dispatchers.IO) {
            familyDao.photoPath(id)?.let { File(it).delete() }
            familyDao.updatePhoto(id, null)
        }
    }

    override suspend fun saveRecording(key: String, file: File) = voices.save(key, file)

    override suspend fun deleteRecording(key: String) = voices.delete(key)
}

class RoomPainRepository(private val dao: PainDao) : PainRepository {
    override suspend fun log(region: PainRegion, severity: PainSeverity) {
        dao.insert(
            PainReportEntity(
                regionKey = region.name,
                severity = severity.level,
                timestamp = System.currentTimeMillis(),
            )
        )
    }
}
