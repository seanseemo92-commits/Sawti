package com.mywords.presentation.practice

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mywords.MyWordsApp
import com.mywords.audio.WordVoice
import com.mywords.domain.model.Category
import com.mywords.domain.model.CategoryIds
import com.mywords.domain.model.WordItem
import com.mywords.domain.repository.WordRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PracticeCard(val item: WordItem, val palette: Int)

data class PracticeUiState(
    val ready: Boolean = false,
    val card: PracticeCard? = null,
    val index: Int = 0,
    val total: Int = 0,
    val revealed: Boolean = false,
    val score: Int = 0,
    val finished: Boolean = false,
)

/**
 * Word-recall practice (confrontation naming): see the picture, try to say the word,
 * use the 💡 cue if needed, then reveal and hear the full word.
 */
class PracticeViewModel(
    private val repository: WordRepository,
    private val voice: WordVoice,
) : ViewModel() {

    private val _uiState = MutableStateFlow(PracticeUiState())
    val uiState: StateFlow<PracticeUiState> = _uiState.asStateFlow()

    private var pool: List<PracticeCard> = emptyList()
    private var deck: List<PracticeCard> = emptyList()

    init {
        viewModelScope.launch {
            repository.observeCategories().collect { categories ->
                pool = buildPool(categories)
                if (deck.isEmpty()) startRound()
            }
        }
    }

    /** Words with a picture. Family only counts once a real photo is attached; daily phrases are skipped. */
    private fun buildPool(categories: List<Category>): List<PracticeCard> =
        categories.filter { it.id != CategoryIds.DAILY }.flatMap { c ->
            c.items
                .filter { if (c.id == CategoryIds.FAMILY) it.photoPath != null else it.emoji.isNotBlank() || it.photoPath != null }
                .map { PracticeCard(it, c.palette) }
        }

    private fun startRound() {
        deck = pool.shuffled().take(ROUND_SIZE)
        _uiState.value = PracticeUiState(
            ready = true,
            card = deck.firstOrNull(),
            total = deck.size,
        )
    }

    fun restart() {
        voice.stop()
        startRound()
    }

    fun hint() {
        _uiState.value.card?.let { voice.hint(it.item) }
    }

    fun reveal() {
        val card = _uiState.value.card ?: return
        _uiState.update { it.copy(revealed = true) }
        voice.play(card.item)
    }

    fun known() {
        _uiState.update { it.copy(score = it.score + 1) }
        next()
    }

    fun next() {
        voice.stop()
        val nextIndex = _uiState.value.index + 1
        if (nextIndex >= deck.size) {
            _uiState.update { it.copy(finished = true, revealed = false) }
        } else {
            _uiState.update { it.copy(index = nextIndex, card = deck[nextIndex], revealed = false) }
        }
    }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val c = (app as MyWordsApp).container
            return PracticeViewModel(c.wordRepository, c.wordVoice) as T
        }
    }

    private companion object {
        const val ROUND_SIZE = 10
    }
}
