package com.mywords.presentation.common

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mywords.R
import com.mywords.presentation.theme.EmergencyRed

/** Hold to switch caregiver mode, so it can't be toggled by an accidental tap. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CaregiverLockButton(enabled: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    Box(
        modifier
            .size(56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) EmergencyRed else MaterialTheme.colorScheme.primaryContainer)
            .combinedClickable(
                onClick = {},
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onToggle()
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (enabled) Icons.Filled.LockOpen else Icons.Filled.Lock,
            contentDescription = stringResource(R.string.caregiver_hint),
            tint = if (enabled) Color.White else MaterialTheme.colorScheme.onPrimaryContainer,
        )
    }
}
