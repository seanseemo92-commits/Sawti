package com.mywords.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface FamilyDao {
    @Query("SELECT * FROM family_members ORDER BY sortOrder")
    fun observeAll(): Flow<List<FamilyMemberEntity>>

    @Query("UPDATE family_members SET spokenPhrase = :phrase, phone = :phone WHERE id = :id")
    suspend fun updateDetails(id: Long, phrase: String, phone: String)

    @Query("SELECT photoPath FROM family_members WHERE id = :id")
    suspend fun photoPath(id: Long): String?

    @Query("UPDATE family_members SET photoPath = :path WHERE id = :id")
    suspend fun updatePhoto(id: Long, path: String?)

    @Insert
    suspend fun insert(member: FamilyMemberEntity): Long
}

@Dao
interface VoiceDao {
    @Query("SELECT * FROM voice_recordings")
    fun observeAll(): Flow<List<VoiceRecordingEntity>>

    @Query("SELECT filePath FROM voice_recordings WHERE recordingKey = :key")
    suspend fun pathFor(key: String): String?

    @Upsert
    suspend fun upsert(recording: VoiceRecordingEntity)

    @Query("DELETE FROM voice_recordings WHERE recordingKey = :key")
    suspend fun delete(key: String)
}

@Dao
interface PainDao {
    @Insert
    suspend fun insert(report: PainReportEntity)

    @Query("SELECT * FROM pain_reports ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<PainReportEntity>>
}
