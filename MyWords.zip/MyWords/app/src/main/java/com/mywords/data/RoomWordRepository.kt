package com.mywords.data

import android.content.Context
import androidx.room.withTransaction
import com.mywords.data.db.AppDatabase
import com.mywords.data.db.WordSeed
import com.mywords.data.db.toDomain
import com.mywords.domain.model.Category
import com.mywords.domain.repository.WordRepository
import java.io.File
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext

class RoomWordRepository(
    private val db: AppDatabase,
    context: Context,
) : WordRepository {

    private val dao = db.wordDao()
    private val filesDir = context.applicationContext.filesDir

    override fun observeCategories(): Flow<List<Category>> =
        combine(dao.observeCategories(), dao.observeItems()) { categories, items ->
            val byCategory = items.groupBy { it.categoryId }
            categories.map { c ->
                Category(
                    id = c.id,
                    title = c.title,
                    palette = c.palette,
                    previewOnTap = c.previewOnTap,
                    items = byCategory[c.id].orEmpty().map { it.toDomain() },
                )
            }
        }

    override suspend fun ensureSeeded() {
        if (dao.categoryCount() > 0) return
        db.withTransaction {
            dao.insertCategories(WordSeed.categoryEntities())
            dao.insertItems(WordSeed.itemEntities())
        }
    }

    override suspend fun updateDetails(id: Long, displayText: String, ttsPrompt: String, phonemicCue: String, phone: String) {
        dao.updateDetails(id, displayText, ttsPrompt, phonemicCue, phone)
    }

    /** Copies the picked image into app storage so it survives even if the gallery item moves. */
    override suspend fun setPhoto(id: Long, image: InputStream) {
        withContext(Dispatchers.IO) {
            val dir = File(filesDir, "photos").apply { mkdirs() }
            val target = File(dir, "word_${id}_${System.currentTimeMillis()}.jpg")
            image.use { input -> target.outputStream().use { input.copyTo(it) } }
            val old = dao.photoPath(id)
            dao.updatePhoto(id, target.absolutePath)
            old?.let { File(it).delete() }
        }
    }

    override suspend fun clearPhoto(id: Long) {
        withContext(Dispatchers.IO) {
            dao.photoPath(id)?.let { File(it).delete() }
            dao.updatePhoto(id, null)
        }
    }

    override suspend fun setAudio(id: Long, file: File) {
        withContext(Dispatchers.IO) {
            val old = dao.audioPath(id)
            dao.updateAudio(id, file.absolutePath)
            if (old != null && old != file.absolutePath) File(old).delete()
        }
    }

    override suspend fun clearAudio(id: Long) {
        withContext(Dispatchers.IO) {
            dao.audioPath(id)?.let { File(it).delete() }
            dao.updateAudio(id, null)
        }
    }
}
