package com.mywords.presentation.family

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mywords.MyWordsApp
import com.mywords.audio.AudioPlayer
import com.mywords.audio.VoiceRecorder
import com.mywords.domain.model.AppLanguage
import com.mywords.domain.model.FamilyMember
import com.mywords.domain.model.RecordingKeys
import com.mywords.domain.repository.FamilyRepository
import com.mywords.speech.SpeechManager
import com.mywords.state.CaregiverMode
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class FamilyUiState(
    val members: List<FamilyMember> = emptyList(),
    val caregiverMode: Boolean = false,
    val activeId: Long? = null,      // card highlighted after a tap
    val editingId: Long? = null,     // member shown in the editor dialog
    val recordingId: Long? = null,   // member whose voice is being recorded right now
)

/** Everything the Family screen can ask for – lets the screen stay free of ViewModel types. */
interface FamilyActions {
    fun onMemberTapped(member: FamilyMember)
    fun onAltPhraseTapped(member: FamilyMember)
    fun onMemberLongPressed(member: FamilyMember)
    fun toggleCaregiverMode()
    fun closeEditor()
    fun saveDetails(id: Long, phrase: String, phone: String)
    fun onPhotoPicked(memberId: Long, uri: Uri)
    fun removePhoto(memberId: Long)
    fun startRecording(memberId: Long)
    fun stopRecording(memberId: Long)
    fun previewRecording(memberId: Long)
    fun deleteRecording(memberId: Long)
}

class FamilyViewModel(
    private val repository: FamilyRepository,
    private val speech: SpeechManager,
    private val player: AudioPlayer,
    private val recorder: VoiceRecorder,
    private val resolver: ContentResolver,
    private val caregiver: CaregiverMode,
) : ViewModel(), FamilyActions {

    private val _uiState = MutableStateFlow(FamilyUiState())
    val uiState: StateFlow<FamilyUiState> = _uiState.asStateFlow()

    private var highlightJob: Job? = null
    private var lastTap: Pair<String, Long>? = null

    init {
        viewModelScope.launch {
            repository.observeMembers().collect { list -> _uiState.update { it.copy(members = list) } }
        }
        // Caregiver mode is shared with the dashboard.
        viewModelScope.launch {
            caregiver.enabled.collect { on -> _uiState.update { it.copy(caregiverMode = on) } }
        }
    }

    // ---- Speaking -------------------------------------------------------

    override fun onMemberTapped(member: FamilyMember) {
        if (_uiState.value.caregiverMode) {
            _uiState.update { it.copy(editingId = member.id) }
        } else {
            announce(member, member.spokenPhrase, key = "p${member.id}", useRecording = true)
        }
    }

    override fun onAltPhraseTapped(member: FamilyMember) {
        member.altPhrase?.let { announce(member, it, key = "a${member.id}", useRecording = false) }
    }

    /** A caregiver recording, when present, replaces TTS for the main phrase. Family phrases are always Arabic. */
    private fun announce(member: FamilyMember, phrase: String, key: String, useRecording: Boolean) {
        val now = SystemClock.elapsedRealtime()
        lastTap?.let { (k, t) -> if (k == key && now - t < DEBOUNCE_MS) return }
        lastTap = key to now

        player.stop()
        val voice = member.voicePath?.takeIf { useRecording && File(it).exists() }
        if (voice != null) {
            speech.stop()
            player.play(voice)
        } else {
            speech.speak(phrase, AppLanguage.ARABIC)
        }

        highlightJob?.cancel()
        _uiState.update { it.copy(activeId = member.id) }
        highlightJob = viewModelScope.launch {
            delay(HIGHLIGHT_MS)
            _uiState.update { it.copy(activeId = null) }
        }
    }

    // ---- Caregiver mode / editor ---------------------------------------

    override fun onMemberLongPressed(member: FamilyMember) {
        _uiState.update { it.copy(editingId = member.id) }
    }

    override fun toggleCaregiverMode() {
        caregiver.toggle()
    }

    override fun closeEditor() {
        recorder.cancel()
        player.stop()
        _uiState.update { it.copy(editingId = null, recordingId = null) }
    }

    override fun saveDetails(id: Long, phrase: String, phone: String) {
        // A blank phrase keeps the old one, but the phone number is always saved.
        val current = _uiState.value.members.firstOrNull { it.id == id } ?: return
        val finalPhrase = phrase.ifBlank { current.spokenPhrase }
        viewModelScope.launch {
            repository.updateDetails(id, finalPhrase, phone)
            closeEditor()
        }
    }

    // ---- Photos ---------------------------------------------------------

    override fun onPhotoPicked(memberId: Long, uri: Uri) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { resolver.openInputStream(uri) }
                ?.let { repository.setPhoto(memberId, it) }
        }
    }

    override fun removePhoto(memberId: Long) {
        viewModelScope.launch { repository.clearPhoto(memberId) }
    }

    // ---- Caregiver voice recordings ------------------------------------

    /** The UI must have RECORD_AUDIO granted before calling this. */
    override fun startRecording(memberId: Long) {
        player.stop()
        speech.stop()
        if (recorder.start(RecordingKeys.family(memberId))) {
            _uiState.update { it.copy(recordingId = memberId) }
        }
    }

    override fun stopRecording(memberId: Long) {
        val file = recorder.stop()
        _uiState.update { it.copy(recordingId = null) }
        if (file != null) {
            viewModelScope.launch { repository.saveRecording(RecordingKeys.family(memberId), file) }
        }
    }

    override fun previewRecording(memberId: Long) {
        _uiState.value.members.firstOrNull { it.id == memberId }?.voicePath?.let { player.play(it) }
    }

    override fun deleteRecording(memberId: Long) {
        player.stop()
        viewModelScope.launch { repository.deleteRecording(RecordingKeys.family(memberId)) }
    }

    override fun onCleared() {
        recorder.cancel()
        player.stop()
    }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val c = (app as MyWordsApp).container
            return FamilyViewModel(
                c.familyRepository, c.speech, c.player, c.recorder, app.contentResolver, c.caregiver
            ) as T
        }
    }

    private companion object {
        const val DEBOUNCE_MS = 500L
        const val HIGHLIGHT_MS = 1200L
    }
}
