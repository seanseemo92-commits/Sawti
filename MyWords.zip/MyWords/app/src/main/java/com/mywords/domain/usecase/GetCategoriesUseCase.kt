package com.mywords.domain.usecase

import com.mywords.domain.model.Category
import com.mywords.domain.repository.CommunicationRepository

class GetCategoriesUseCase(private val repository: CommunicationRepository) {
    operator fun invoke(): List<Category> = repository.getCategories()
}
