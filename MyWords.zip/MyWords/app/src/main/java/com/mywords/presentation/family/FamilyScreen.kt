package com.mywords.presentation.family

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.mywords.R
import com.mywords.domain.model.FamilyGroup
import com.mywords.domain.model.FamilyMember
import com.mywords.presentation.common.CaregiverLockButton
import com.mywords.presentation.common.VoiceRecordingSection
import com.mywords.presentation.theme.BurntOrange
import com.mywords.presentation.theme.DeepPurple
import com.mywords.presentation.theme.EmergencyRed
import com.mywords.presentation.theme.ForestGreen
import com.mywords.presentation.theme.HighlightYellow
import com.mywords.presentation.theme.NavyBlue
import java.io.File

@StringRes
private fun FamilyGroup.titleRes(): Int = when (this) {
    FamilyGroup.HUSBAND -> R.string.group_husband
    FamilyGroup.CHILDREN -> R.string.group_children
    FamilyGroup.SISTERS -> R.string.group_sisters
    FamilyGroup.BROTHERS -> R.string.group_brothers
}

private fun FamilyGroup.accent(): Color = when (this) {
    FamilyGroup.HUSBAND -> NavyBlue
    FamilyGroup.CHILDREN -> ForestGreen
    FamilyGroup.SISTERS -> DeepPurple
    FamilyGroup.BROTHERS -> BurntOrange
}

@Composable
fun FamilyRoute(viewModel: FamilyViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    FamilyScreen(state = state, actions = viewModel)
}

@Composable
fun FamilyScreen(state: FamilyUiState, actions: FamilyActions) {
    var selected by rememberSaveable { mutableStateOf(FamilyGroup.HUSBAND) }
    val groups = FamilyGroup.entries
    val context = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        FamilyHeader(state.caregiverMode, actions::toggleCaregiverMode)

        // Sub-tabs: الزوج / الأبناء / الأخوات / الإخوة
        TabRow(selectedTabIndex = groups.indexOf(selected)) {
            groups.forEach { group ->
                Tab(
                    selected = group == selected,
                    onClick = { selected = group },
                    modifier = Modifier.heightIn(min = 64.dp),
                    text = {
                        Text(stringResource(group.titleRes()), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    },
                )
            }
        }

        val members = state.members.filter { it.group == selected }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 156.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(members, key = { it.id }) { member ->
                MemberCard(
                    member = member,
                    isActive = state.activeId == member.id,
                    caregiverMode = state.caregiverMode,
                    onClick = { actions.onMemberTapped(member) },
                    onLongClick = { actions.onMemberLongPressed(member) },
                    onAlt = { actions.onAltPhraseTapped(member) },
                    onCall = {
                        try {
                            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", member.phone, null)))
                        } catch (_: ActivityNotFoundException) { }
                    },
                )
            }
        }
    }

    state.editingId?.let { id ->
        state.members.firstOrNull { it.id == id }?.let { member ->
            EditMemberDialog(member, isRecording = state.recordingId == member.id, actions = actions)
        }
    }
}

// ------------------------------------------------------------------ header

@Composable
private fun FamilyHeader(caregiverMode: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.family_title), fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                stringResource(if (caregiverMode) R.string.caregiver_banner else R.string.caregiver_hint),
                fontSize = 14.sp,
                color = if (caregiverMode) EmergencyRed else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            )
        }
        CaregiverLockButton(enabled = caregiverMode, onToggle = onToggle)
    }
}

// ------------------------------------------------------------------ card

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MemberCard(
    member: FamilyMember,
    isActive: Boolean,
    caregiverMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onAlt: () -> Unit,
    onCall: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val accent = member.group.accent()
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = if (isActive) HighlightYellow else accent,
        contentColor = if (isActive) Color.Black else Color.White,
        border = if (isActive) BorderStroke(4.dp, Color.Black) else null,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier
                .combinedClickable(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onClick()
                    },
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onLongClick()
                    },
                )
                .heightIn(min = 190.dp)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box {
                Avatar(member.photoPath, size = 104.dp, tint = accent)
                if (caregiverMode) {
                    Icon(
                        Icons.Filled.Edit,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(32.dp)
                            .background(EmergencyRed, CircleShape)
                            .padding(6.dp),
                    )
                }
            }
            Spacer(Modifier.size(10.dp))
            Text(member.name, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)

            member.altPhrase?.let { alt ->
                Spacer(Modifier.size(8.dp))
                Button(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onAlt()
                    },
                    modifier = Modifier.heightIn(min = 56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = accent),
                ) { Text(alt, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            }

            if (member.phone.isNotBlank() && caregiverMode) {
                Text(member.phone, fontSize = 16.sp, modifier = Modifier.padding(top = 4.dp))
            }
            if (member.phone.isNotBlank() && !caregiverMode) {
                Spacer(Modifier.size(8.dp))
                OutlinedButton(
                    onClick = onCall,
                    modifier = Modifier.heightIn(min = 56.dp),
                    border = BorderStroke(2.dp, Color.White),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                ) {
                    Icon(Icons.Filled.Call, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.call), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** Real photo when one is attached, otherwise a placeholder person icon. */
@Composable
private fun Avatar(photoPath: String?, size: Dp, tint: Color) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White),
        contentAlignment = Alignment.Center,
    ) {
        if (photoPath != null) {
            AsyncImage(
                model = File(photoPath),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(Icons.Filled.Person, contentDescription = null, tint = tint, modifier = Modifier.size(size * 0.7f))
        }
    }
}

// ------------------------------------------------------------------ caregiver editor

@Composable
private fun EditMemberDialog(member: FamilyMember, isRecording: Boolean, actions: FamilyActions) {
    var phrase by remember(member.id) { mutableStateOf(member.spokenPhrase) }
    var phone by remember(member.id) { mutableStateOf(member.phone) }

    // System photo picker: no storage permission needed.
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) actions.onPhotoPicked(member.id, uri)
    }

    AlertDialog(
        onDismissRequest = actions::closeEditor,
        title = { Text(member.name, fontSize = 26.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                OutlinedTextField(
                    value = phrase,
                    onValueChange = { phrase = it },
                    label = { Text(stringResource(R.string.field_phrase)) },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = normalizePhone(it) },
                    label = { Text(stringResource(R.string.field_phone)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                )

                // Photo
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Avatar(member.photoPath, size = 80.dp, tint = member.group.accent())
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.heightIn(min = 52.dp),
                        ) {
                            Icon(Icons.Filled.PhotoLibrary, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.choose_photo))
                        }
                        if (member.photoPath != null) {
                            TextButton(onClick = { actions.removePhoto(member.id) }) {
                                Text(stringResource(R.string.remove_photo))
                            }
                        }
                    }
                }

                // Custom voice (shared with the dashboard tile editor)
                VoiceRecordingSection(
                    hasRecording = member.voicePath != null,
                    isRecording = isRecording,
                    onStart = { actions.startRecording(member.id) },
                    onStop = { actions.stopRecording(member.id) },
                    onPlay = { actions.previewRecording(member.id) },
                    onDelete = { actions.deleteRecording(member.id) },
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { actions.saveDetails(member.id, phrase.trim(), phone.trim()) },
                modifier = Modifier.heightIn(min = 52.dp),
            ) { Text(stringResource(R.string.save), fontSize = 18.sp) }
        },
        dismissButton = {
            TextButton(onClick = actions::closeEditor, modifier = Modifier.heightIn(min = 52.dp)) {
                Text(stringResource(R.string.cancel), fontSize = 18.sp)
            }
        },
    )
}

/** Keeps digits, + - ( ) and spaces; converts Arabic-Indic digits so the dialer always gets 0-9. */
private fun normalizePhone(raw: String): String = buildString {
    raw.forEach { c ->
        when (c) {
            in '0'..'9', '+', '-', ' ', '(', ')' -> append(c)
            in '\u0660'..'\u0669' -> append('0' + (c - '\u0660'))
        }
    }
}
