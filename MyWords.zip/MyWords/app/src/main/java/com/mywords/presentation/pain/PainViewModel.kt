package com.mywords.presentation.pain

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mywords.MyWordsApp
import com.mywords.domain.model.AppLanguage
import com.mywords.domain.model.BodyView
import com.mywords.domain.model.PainPhrases
import com.mywords.domain.model.PainRegion
import com.mywords.domain.model.PainSeverity
import com.mywords.domain.repository.PainRepository
import com.mywords.speech.SpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PainUiState(
    val view: BodyView = BodyView.FRONT,
    val region: PainRegion? = null,
    val severity: PainSeverity? = null,
)

class PainViewModel(
    private val speech: SpeechManager,
    private val repository: PainRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(PainUiState())
    val uiState: StateFlow<PainUiState> = _uiState.asStateFlow()

    fun setView(view: BodyView) = _uiState.update { PainUiState(view = view) }

    fun selectRegion(region: PainRegion) = _uiState.update { it.copy(region = region, severity = null) }

    /** Choosing a severity completes the sentence: speak it and log it for the caregiver/doctor. */
    fun selectSeverity(severity: PainSeverity, language: AppLanguage) {
        val region = _uiState.value.region ?: return
        _uiState.update { it.copy(severity = severity) }
        speech.speak(PainPhrases.build(region, severity, language), language)
        viewModelScope.launch { repository.log(region, severity) }
    }

    fun speakAgain(language: AppLanguage) {
        val s = _uiState.value
        val region = s.region ?: return
        val severity = s.severity ?: return
        speech.speak(PainPhrases.build(region, severity, language), language)
    }

    fun clear() = _uiState.update { PainUiState(view = it.view) }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val c = (app as MyWordsApp).container
            return PainViewModel(c.speech, c.painRepository) as T
        }
    }
}
