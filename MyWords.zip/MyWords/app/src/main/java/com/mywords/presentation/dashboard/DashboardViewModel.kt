package com.mywords.presentation.dashboard

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mywords.MyWordsApp
import com.mywords.audio.AlertChime
import com.mywords.audio.AudioPlayer
import com.mywords.audio.VoiceRecorder
import com.mywords.data.SettingsStore
import com.mywords.data.StaticCommunicationRepository
import com.mywords.domain.model.AppLanguage
import com.mywords.domain.model.Category
import com.mywords.domain.model.CommunicationItem
import com.mywords.domain.model.DisplayMode
import com.mywords.domain.model.EmergencyPhrase
import com.mywords.domain.model.RecordingKeys
import com.mywords.domain.repository.VoiceRepository
import com.mywords.domain.usecase.GetCategoriesUseCase
import com.mywords.locale.LocaleManager
import com.mywords.speech.SpeechIssue
import com.mywords.speech.SpeechManager
import com.mywords.state.CaregiverMode
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DashboardUiState(
    val categories: List<Category> = emptyList(),
    val language: AppLanguage = AppLanguage.ENGLISH,
    val displayMode: DisplayMode = DisplayMode.SINGLE,
    /** Tile currently highlighted after a tap. */
    val activeItemId: String? = null,
    val emergencyActive: Boolean = false,
    val chimeActive: Boolean = false,
    val speechIssue: SpeechIssue? = null,
    // --- caregiver tools ---
    val caregiverMode: Boolean = false,
    val editingItemId: String? = null,    // tile shown in the voice editor
    val recordingItemId: String? = null,  // tile being recorded right now
    /** RecordingKeys that currently have a saved recording (used for the mic badge). */
    val recordedKeys: Set<String> = emptySet(),
)

/** What the tile voice editor can ask for. */
interface TileEditorActions {
    fun closeEditor()
    fun startRecording(itemId: String)
    fun stopRecording(itemId: String)
    fun previewRecording(itemId: String)
    fun deleteRecording(itemId: String)
}

/**
 * Also owns the app-wide header actions (emergency phrase + loud chime) because the
 * header is shown on every screen. Speech, audio and recorder are shared via AppContainer.
 */
class DashboardViewModel(
    getCategories: GetCategoriesUseCase,
    private val speech: SpeechManager,
    private val chime: AlertChime,
    private val settings: SettingsStore,
    private val voices: VoiceRepository,
    private val player: AudioPlayer,
    private val recorder: VoiceRecorder,
    private val caregiver: CaregiverMode,
    initialLanguage: AppLanguage,
) : ViewModel(), TileEditorActions {

    private val _uiState = MutableStateFlow(
        DashboardUiState(
            categories = getCategories(),
            language = initialLanguage,
            displayMode = settings.displayMode,
        )
    )
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private var recordingPaths: Map<String, String> = emptyMap()
    private var highlightJob: Job? = null
    private var emergencyJob: Job? = null
    private var chimeJob: Job? = null
    private var lastTap: Pair<String, Long>? = null

    init {
        viewModelScope.launch {
            speech.issue.collect { issue -> _uiState.update { it.copy(speechIssue = issue) } }
        }
        viewModelScope.launch {
            voices.observeRecordings().collect { map ->
                recordingPaths = map
                _uiState.update { it.copy(recordedKeys = map.keys) }
            }
        }
        viewModelScope.launch {
            caregiver.enabled.collect { on ->
                _uiState.update { it.copy(caregiverMode = on, editingItemId = if (on) it.editingItemId else null) }
            }
        }
    }

    // ---- Tapping a tile -------------------------------------------------

    fun onItemTapped(item: CommunicationItem) {
        val state = _uiState.value
        if (state.caregiverMode) {
            _uiState.update { it.copy(editingItemId = item.id) }
            return
        }

        // Ignore accidental double-taps (tremor) on the same tile.
        val now = SystemClock.elapsedRealtime()
        lastTap?.let { (id, time) -> if (id == item.id && now - time < DEBOUNCE_MS) return }
        lastTap = item.id to now

        // A caregiver recording for the current language replaces TTS.
        val language = state.language
        val voice = recordingPaths[RecordingKeys.item(item.id, language)]?.takeIf { File(it).exists() }
        if (voice != null) {
            speech.stop()
            player.play(voice)
        } else {
            player.stop()
            speech.speak(item.spoken.get(language), language)
        }

        highlightJob?.cancel()
        _uiState.update { it.copy(activeItemId = item.id) }
        highlightJob = viewModelScope.launch {
            delay(HIGHLIGHT_MS)
            _uiState.update { it.copy(activeItemId = null) }
        }
    }

    /** Long-press only does something in caregiver mode, so the patient can't open the editor by accident. */
    fun onItemLongPressed(item: CommunicationItem) {
        if (_uiState.value.caregiverMode) _uiState.update { it.copy(editingItemId = item.id) }
    }

    fun onCaregiverToggled() = caregiver.toggle()

    // ---- Tile voice editor ----------------------------------------------

    override fun closeEditor() {
        recorder.cancel()
        player.stop()
        _uiState.update { it.copy(editingItemId = null, recordingItemId = null) }
    }

    /** The UI must have RECORD_AUDIO granted before calling this. */
    override fun startRecording(itemId: String) {
        player.stop()
        speech.stop()
        val key = RecordingKeys.item(itemId, _uiState.value.language)
        if (recorder.start(key)) _uiState.update { it.copy(recordingItemId = itemId) }
    }

    override fun stopRecording(itemId: String) {
        val key = RecordingKeys.item(itemId, _uiState.value.language)
        val file = recorder.stop()
        _uiState.update { it.copy(recordingItemId = null) }
        if (file != null) viewModelScope.launch { voices.save(key, file) }
    }

    override fun previewRecording(itemId: String) {
        recordingPaths[RecordingKeys.item(itemId, _uiState.value.language)]?.let { player.play(it) }
    }

    override fun deleteRecording(itemId: String) {
        player.stop()
        val key = RecordingKeys.item(itemId, _uiState.value.language)
        viewModelScope.launch { voices.delete(key) }
    }

    // ---- Header actions (every screen) ----------------------------------

    fun onEmergencyPressed() {
        player.stop()
        val language = _uiState.value.language
        speech.speak(EmergencyPhrase.text.get(language), language, repeat = 3)
        _uiState.update { it.copy(emergencyActive = true) }

        emergencyJob?.cancel()
        emergencyJob = viewModelScope.launch {
            delay(EMERGENCY_BANNER_MS)
            _uiState.update { it.copy(emergencyActive = false) }
        }
    }

    fun onEmergencyStopped() {
        emergencyJob?.cancel()
        speech.stop()
        _uiState.update { it.copy(emergencyActive = false) }
    }

    /** Tap once to start the loud chime, tap again to stop. Auto-stops after 30 s. */
    fun onChimeToggled() {
        if (_uiState.value.chimeActive) {
            chimeJob?.cancel()
            return
        }
        _uiState.update { it.copy(chimeActive = true) }
        chimeJob = viewModelScope.launch {
            try {
                chime.start()
                repeat(CHIME_MAX_BEEPS) {
                    chime.beep()
                    delay(1000)
                }
            } finally {
                chime.stop()
                _uiState.update { it.copy(chimeActive = false) }
            }
        }
    }

    fun onLanguageSelected(language: AppLanguage) {
        if (language == _uiState.value.language) return
        speech.stop()
        player.stop()
        _uiState.update { it.copy(language = language) }
        LocaleManager.apply(language) // recreates the activity → RTL/LTR flips
    }

    fun onDisplayModeChanged(mode: DisplayMode) {
        settings.displayMode = mode
        _uiState.update { it.copy(displayMode = mode) }
    }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val c = (app as MyWordsApp).container
            return DashboardViewModel(
                getCategories = GetCategoriesUseCase(StaticCommunicationRepository()),
                speech = c.speech,
                chime = c.chime,
                settings = SettingsStore(app),
                voices = c.voiceRepository,
                player = c.player,
                recorder = c.recorder,
                caregiver = c.caregiver,
                initialLanguage = LocaleManager.current(app),
            ) as T
        }
    }

    private companion object {
        const val DEBOUNCE_MS = 500L
        const val HIGHLIGHT_MS = 1200L
        const val EMERGENCY_BANNER_MS = 20_000L
        const val CHIME_MAX_BEEPS = 30
    }
}
