package com.mywords.presentation.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mywords.R
import com.mywords.presentation.dashboard.DashboardRoute
import com.mywords.presentation.dashboard.DashboardViewModel
import com.mywords.presentation.dashboard.EmergencyActiveBanner
import com.mywords.presentation.dashboard.EmergencyBar
import com.mywords.presentation.family.FamilyRoute
import com.mywords.presentation.family.FamilyViewModel
import com.mywords.presentation.pain.PainRoute
import com.mywords.presentation.pain.PainViewModel

private enum class Destination(val labelRes: Int, val icon: ImageVector) {
    HOME(R.string.nav_home, Icons.Filled.Home),
    FAMILY(R.string.nav_family, Icons.Filled.People),
    PAIN(R.string.nav_pain, Icons.Filled.Accessibility),
}

/**
 * Emergency bar + loud chime live in the top bar of every screen,
 * so help is always one tap away.
 */
@Composable
fun AppRoot(
    dashboardVm: DashboardViewModel,
    familyVm: FamilyViewModel,
    painVm: PainViewModel,
) {
    var destination by rememberSaveable { mutableStateOf(Destination.HOME) }
    val dash by dashboardVm.uiState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column(
                Modifier
                    .background(MaterialTheme.colorScheme.background)
                    .statusBarsPadding()
            ) {
                EmergencyBar(
                    chimeOn = dash.chimeActive,
                    onEmergency = dashboardVm::onEmergencyPressed,
                    onChime = dashboardVm::onChimeToggled,
                )
                AnimatedVisibility(dash.emergencyActive) {
                    EmergencyActiveBanner(dashboardVm::onEmergencyStopped)
                }
            }
        },
        bottomBar = {
            NavigationBar {
                Destination.entries.forEach { d ->
                    NavigationBarItem(
                        selected = destination == d,
                        onClick = { destination = d },
                        icon = { Icon(d.icon, contentDescription = null) },
                        label = { Text(stringResource(d.labelRes), fontSize = 14.sp, fontWeight = FontWeight.Bold) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (destination) {
                Destination.HOME -> DashboardRoute(dashboardVm)
                Destination.FAMILY -> FamilyRoute(familyVm)
                Destination.PAIN -> PainRoute(painVm, language = dash.language)
            }
        }
    }
}
