package com.mywords.domain.repository

import java.io.File
import kotlinx.coroutines.flow.Flow

/** Caregiver voice recordings, keyed by RecordingKeys (family members, dashboard tiles, …). */
interface VoiceRepository {
    /** key -> absolute file path */
    fun observeRecordings(): Flow<Map<String, String>>
    suspend fun save(key: String, file: File)
    suspend fun delete(key: String)
}
