package com.mywords.domain.model

enum class FamilyGroup { HUSBAND, CHILDREN, SISTERS, BROTHERS }

/**
 * [spokenPhrase] is what the tile says; [altPhrase] is an optional second phrase
 * (e.g. the husband's "وين محمد؟"). [voicePath] is a caregiver recording that,
 * when present, replaces TTS for [spokenPhrase].
 */
data class FamilyMember(
    val id: Long,
    val group: FamilyGroup,
    val name: String,
    val spokenPhrase: String,
    val altPhrase: String?,
    val phone: String,
    val photoPath: String?,
    val voicePath: String?,
)

/**
 * Keys for the generic recordings table – any phrase can get a custom voice.
 * Dashboard tiles are recorded per language ("item:water:ar" / "item:water:en") so the
 * Arabic recording only plays while the app is in Arabic.
 */
object RecordingKeys {
    fun family(memberId: Long) = "family:$memberId"
    fun item(itemId: String, language: AppLanguage) = "item:$itemId:${language.tag}"
}
