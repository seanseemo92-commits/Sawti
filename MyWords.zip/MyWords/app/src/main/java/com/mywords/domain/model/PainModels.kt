package com.mywords.domain.model

enum class BodyView { FRONT, BACK }

/**
 * Tappable body areas. Left/right are the PATIENT's own sides; the screen shows
 * the patient's right on the screen's right in both views.
 * Arabic is Libyan-dialect phrasing ("عندي وجع في …").
 */
enum class PainRegion(val view: BodyView, val ar: String, val en: String) {
    HEAD(BodyView.FRONT, "راسي", "my head"),
    CHEST(BodyView.FRONT, "صدري", "my chest"),
    STOMACH(BodyView.FRONT, "كرشي", "my stomach"),
    SHOULDER_R(BodyView.FRONT, "كتفي اليمين", "my right shoulder"),
    SHOULDER_L(BodyView.FRONT, "كتفي اليسار", "my left shoulder"),
    ARM_R(BodyView.FRONT, "يدي اليمين", "my right arm"),
    ARM_L(BodyView.FRONT, "يدي اليسار", "my left arm"),
    HIP_R(BodyView.FRONT, "وركي اليمين", "my right hip"),
    HIP_L(BodyView.FRONT, "وركي اليسار", "my left hip"),
    KNEE_R(BodyView.FRONT, "ركبتي اليمين", "my right knee"),
    KNEE_L(BodyView.FRONT, "ركبتي اليسار", "my left knee"),
    LEG_R(BodyView.FRONT, "رجلي اليمين", "my right leg"),
    LEG_L(BodyView.FRONT, "رجلي اليسار", "my left leg"),
    BACK_HEAD(BodyView.BACK, "مؤخرة راسي", "the back of my head"),
    UPPER_BACK(BodyView.BACK, "أعلى ظهري", "my upper back"),
    LOWER_BACK(BodyView.BACK, "أسفل ظهري", "my lower back");

    fun label(language: AppLanguage) = if (language == AppLanguage.ARABIC) ar else en
}

enum class PainSeverity(
    val level: Int,
    val shortAr: String, val shortEn: String,
    val sentenceAr: String, val sentenceEn: String,
) {
    L1(1, "شوية", "A little", "الوجع خفيف شوية.", "It hurts a little."),
    L2(2, "خفيف", "Mild", "الوجع خفيف.", "It is mild."),
    L3(3, "متوسط", "Moderate", "الوجع متوسط.", "It is moderate."),
    L4(4, "قوي", "Strong", "الوجع قوي.", "It is strong."),
    L5(5, "قوي كثير", "Severe", "الوجع قوي كثير، ما نقدرش نتحمله.", "It is severe. I cannot stand it.");

    fun label(language: AppLanguage) = if (language == AppLanguage.ARABIC) shortAr else shortEn
}

object PainPhrases {
    fun build(region: PainRegion, severity: PainSeverity, language: AppLanguage): String =
        when (language) {
            AppLanguage.ARABIC -> "عندي وجع في ${region.ar}. ${severity.sentenceAr}"
            AppLanguage.ENGLISH -> "I have pain in ${region.en}. ${severity.sentenceEn}"
        }
}
