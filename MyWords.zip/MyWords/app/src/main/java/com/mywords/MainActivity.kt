package com.mywords

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.mywords.presentation.dashboard.DashboardViewModel
import com.mywords.presentation.family.FamilyViewModel
import com.mywords.presentation.navigation.AppRoot
import com.mywords.presentation.pain.PainViewModel
import com.mywords.presentation.theme.MyWordsTheme

// AppCompatActivity (not ComponentActivity) is required for AppCompatDelegate locale switching.
class MainActivity : AppCompatActivity() {

    // ViewModels survive the recreation caused by a language switch.
    private val dashboardVm: DashboardViewModel by viewModels { DashboardViewModel.Factory(application) }
    private val familyVm: FamilyViewModel by viewModels { FamilyViewModel.Factory(application) }
    private val painVm: PainViewModel by viewModels { PainViewModel.Factory(application) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // An AAC device should not dim or lock mid-conversation.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            MyWordsTheme {
                AppRoot(dashboardVm, familyVm, painVm)
            }
        }
    }
}
