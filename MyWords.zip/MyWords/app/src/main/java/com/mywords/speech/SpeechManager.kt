package com.mywords.speech

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import com.mywords.domain.model.AppLanguage
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Problems the UI should surface so a caregiver can fix them. */
sealed interface SpeechIssue {
    data object EngineUnavailable : SpeechIssue
    data class MissingVoice(val language: AppLanguage) : SpeechIssue
}

/**
 * Wraps Android TextToSpeech.
 *  - Queues one request made before the engine finished initialising.
 *  - Switches between Locale("ar") and Locale("en") per request.
 *  - Reports missing voice data instead of failing silently.
 */
class SpeechManager(context: Context) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var pending: (() -> Unit)? = null
    private var appliedLanguage: AppLanguage? = null

    private val _issue = MutableStateFlow<SpeechIssue?>(null)
    val issue: StateFlow<SpeechIssue?> = _issue.asStateFlow()

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            _issue.value = SpeechIssue.EngineUnavailable
            return
        }
        tts.setAudioAttributes(
            AudioAttributes.Builder()
                // USAGE_MEDIA so the hardware volume keys control the loudness
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        tts.setSpeechRate(0.85f) // slightly slower = clearer for listeners
        ready = true
        pending?.invoke()
        pending = null
    }

    /** Speaks [text] in [language]. [repeat] > 1 is used by the emergency call. */
    fun speak(text: String, language: AppLanguage, repeat: Int = 1) {
        val action = { speakNow(text, language, repeat) }
        if (ready) action() else pending = action
    }

    fun stop() {
        pending = null
        tts.stop()
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }

    private fun speakNow(text: String, language: AppLanguage, repeat: Int) {
        if (!applyLanguage(language)) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mw-0")
        for (i in 1 until repeat) {
            tts.speak(text, TextToSpeech.QUEUE_ADD, null, "mw-$i")
        }
    }

    /** Tries the plain language first, then common regional variants. */
    private fun applyLanguage(language: AppLanguage): Boolean {
        if (appliedLanguage == language) return true

        val candidates = when (language) {
            AppLanguage.ARABIC -> listOf(
                Locale.forLanguageTag("ar"),
                Locale.forLanguageTag("ar-SA"),
                Locale.forLanguageTag("ar-EG"),
            )
            AppLanguage.ENGLISH -> listOf(
                Locale.forLanguageTag("en"),
                Locale.forLanguageTag("en-US"),
                Locale.forLanguageTag("en-GB"),
            )
        }
        for (locale in candidates) {
            val result = tts.setLanguage(locale)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                appliedLanguage = language
                _issue.value = null
                return true
            }
        }
        appliedLanguage = null
        _issue.value = SpeechIssue.MissingVoice(language)
        return false
    }
}
