package com.mywords.speech

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Problems the UI surfaces so a caregiver can fix them. */
sealed interface SpeechIssue {
    data object EngineUnavailable : SpeechIssue
    data object MissingArabicVoice : SpeechIssue
}

/**
 * Arabic text-to-speech (rate 0.85) that never crashes or goes mute:
 *  - tries Locale("ar") first, then ar-SA / ar-EG / ar-AE / ar-JO, then any installed Arabic voice;
 *  - LANG_MISSING_DATA / LANG_NOT_SUPPORTED are handled (banner offers to install the voice) and speech is
 *    still attempted with the engine's current voice;
 *  - a failed engine start is retried on the next speak().
 * Holds only the application context, so Activity recreation (theme toggle) cannot leak or stop it.
 */
class SpeechManager(context: Context) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var ready = false
    private var arabicReady = false
    private var speechRate = 0.85f
    private var pending: (() -> Unit)? = null

    private val _issue = MutableStateFlow<SpeechIssue?>(null)
    val issue: StateFlow<SpeechIssue?> = _issue.asStateFlow()

    init {
        createEngine()
    }

    private fun createEngine() {
        ready = false
        arabicReady = false
        tts = runCatching { TextToSpeech(appContext, this) }.getOrNull()
        if (tts == null) _issue.value = SpeechIssue.EngineUnavailable
    }

    override fun onInit(status: Int) {
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            _issue.value = SpeechIssue.EngineUnavailable
            runCatching { engine?.shutdown() }
            tts = null // next speak() creates a fresh engine
            return
        }
        runCatching {
            engine.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA) // hardware volume keys control loudness
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            engine.setSpeechRate(speechRate)
        }
        ready = true
        pending?.invoke()
        pending = null
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        if (tts == null) createEngine()
        val action = { speakNow(text) }
        if (ready) action() else pending = action
    }

    /** Applied immediately and to every following utterance (0.75 / 0.85 / 1.0). */
    fun setSpeechRate(rate: Float) {
        speechRate = rate
        runCatching { tts?.setSpeechRate(rate) }
    }

    fun stop() {
        pending = null
        runCatching { tts?.stop() }
    }

    private fun speakNow(text: String) {
        val engine = tts ?: return
        runCatching {
            ensureArabic(engine)
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mw-${System.nanoTime()}")
        }
    }

    /** Best effort: never throws and never blocks speech. */
    private fun ensureArabic(engine: TextToSpeech) {
        if (arabicReady) return
        for (tag in listOf("ar", "ar-SA", "ar-EG", "ar-AE", "ar-JO")) {
            val result = runCatching { engine.setLanguage(Locale.forLanguageTag(tag)) }
                .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                arabicReady = true
                _issue.value = null
                return
            }
        }
        val voice = runCatching { engine.voices }.getOrNull()?.firstOrNull { it.locale.language == "ar" }
        if (voice != null && runCatching { engine.setVoice(voice) }.getOrDefault(TextToSpeech.ERROR) == TextToSpeech.SUCCESS) {
            arabicReady = true
            _issue.value = null
            return
        }
        _issue.value = SpeechIssue.MissingArabicVoice
    }
}
