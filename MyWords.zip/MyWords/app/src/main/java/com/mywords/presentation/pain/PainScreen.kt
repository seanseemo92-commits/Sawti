package com.mywords.presentation.pain

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mywords.R
import com.mywords.domain.model.AppLanguage
import com.mywords.domain.model.BodyView
import com.mywords.domain.model.PainRegion
import com.mywords.domain.model.PainSeverity
import com.mywords.presentation.theme.HighlightYellow
import com.mywords.presentation.theme.NavyBlue

// ---- Geometry: each region is a rectangle in 0..1 space (the map is drawn at aspect 1:2).
private fun PainRegion.bounds(): Rect = when (this) {
    PainRegion.HEAD, PainRegion.BACK_HEAD -> Rect(0.39f, 0.01f, 0.61f, 0.15f)
    PainRegion.CHEST -> Rect(0.32f, 0.18f, 0.68f, 0.36f)
    PainRegion.STOMACH -> Rect(0.32f, 0.37f, 0.68f, 0.52f)
    // Patient's RIGHT is drawn on the screen's right (both views).
    PainRegion.SHOULDER_R -> Rect(0.70f, 0.18f, 0.84f, 0.27f)
    PainRegion.SHOULDER_L -> Rect(0.16f, 0.18f, 0.30f, 0.27f)
    PainRegion.ARM_R -> Rect(0.74f, 0.28f, 0.90f, 0.55f)
    PainRegion.ARM_L -> Rect(0.10f, 0.28f, 0.26f, 0.55f)
    PainRegion.HIP_R -> Rect(0.51f, 0.53f, 0.69f, 0.67f)
    PainRegion.HIP_L -> Rect(0.31f, 0.53f, 0.49f, 0.67f)
    PainRegion.KNEE_R -> Rect(0.52f, 0.68f, 0.68f, 0.77f)
    PainRegion.KNEE_L -> Rect(0.32f, 0.68f, 0.48f, 0.77f)
    PainRegion.LEG_R -> Rect(0.52f, 0.78f, 0.68f, 0.97f)
    PainRegion.LEG_L -> Rect(0.32f, 0.78f, 0.48f, 0.97f)
    PainRegion.UPPER_BACK -> Rect(0.30f, 0.18f, 0.70f, 0.40f)
    PainRegion.LOWER_BACK -> Rect(0.32f, 0.41f, 0.68f, 0.55f)
}

private fun PainRegion.isOval() = this == PainRegion.HEAD || this == PainRegion.BACK_HEAD

// Non-tappable body parts that complete the silhouette.
private val FrontDecor = listOf(
    Rect(0.46f, 0.14f, 0.54f, 0.19f),
    Rect(0.74f, 0.56f, 0.90f, 0.63f), Rect(0.10f, 0.56f, 0.26f, 0.63f),
)
private val BackDecor = listOf(
    Rect(0.46f, 0.14f, 0.54f, 0.19f),
    Rect(0.72f, 0.20f, 0.88f, 0.55f), Rect(0.12f, 0.20f, 0.28f, 0.55f),
    Rect(0.52f, 0.56f, 0.68f, 0.97f), Rect(0.32f, 0.56f, 0.48f, 0.97f),
)

private fun PainSeverity.color(): Color = when (this) {
    PainSeverity.L1 -> Color(0xFFFBC02D)
    PainSeverity.L2 -> Color(0xFFF57C00)
    PainSeverity.L3 -> Color(0xFFE64A19)
    PainSeverity.L4 -> Color(0xFFD32F2F)
    PainSeverity.L5 -> Color(0xFF7F0000)
}

@Composable
fun PainRoute(viewModel: PainViewModel, language: AppLanguage) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    PainScreen(
        state = state,
        language = language,
        onViewChange = viewModel::setView,
        onRegion = viewModel::selectRegion,
        onSeverity = { viewModel.selectSeverity(it, language) },
        onSpeakAgain = { viewModel.speakAgain(language) },
        onClear = viewModel::clear,
    )
}

@Composable
fun PainScreen(
    state: PainUiState,
    language: AppLanguage,
    onViewChange: (BodyView) -> Unit,
    onRegion: (PainRegion) -> Unit,
    onSeverity: (PainSeverity) -> Unit,
    onSpeakAgain: () -> Unit,
    onClear: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.pain_title), fontSize = 28.sp, fontWeight = FontWeight.Bold)

        // Front / Back
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(BodyView.FRONT to R.string.pain_front, BodyView.BACK to R.string.pain_back).forEach { (v, label) ->
                val on = state.view == v
                Button(
                    onClick = { onViewChange(v) },
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (on) NavyBlue else MaterialTheme.colorScheme.primaryContainer,
                        contentColor = if (on) Color.White else MaterialTheme.colorScheme.onPrimaryContainer,
                    ),
                ) { Text(stringResource(label), fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            BodyMap(
                view = state.view,
                selected = state.region,
                severity = state.severity,
                onRegion = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onRegion(it)
                },
                modifier = Modifier.weight(1f),
            )

            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = state.region?.label(language) ?: stringResource(R.string.pain_pick_region),
                    fontSize = if (state.region != null) 26.sp else 18.sp,
                    fontWeight = FontWeight.Bold,
                )
                if (state.region != null) {
                    Text(stringResource(R.string.pain_pick_severity), fontSize = 16.sp)
                }
                PainSeverity.entries.forEach { s ->
                    SeverityButton(
                        severity = s,
                        language = language,
                        enabled = state.region != null,
                        selected = state.severity == s,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onSeverity(s)
                        },
                    )
                }
            }
        }

        Button(
            onClick = onSpeakAgain,
            enabled = state.region != null && state.severity != null,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 64.dp),
        ) { Text(stringResource(R.string.pain_speak_again), fontSize = 22.sp, fontWeight = FontWeight.Bold) }

        OutlinedButton(
            onClick = onClear,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp),
        ) { Text(stringResource(R.string.pain_clear), fontSize = 18.sp) }
    }
}

@Composable
private fun SeverityButton(
    severity: PainSeverity,
    language: AppLanguage,
    enabled: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val color = severity.color()
    val onColor = if (severity == PainSeverity.L1) Color.Black else Color.White
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = if (enabled) 1f else 0.35f),
        contentColor = onColor,
        border = if (selected) BorderStroke(4.dp, Color.Black) else null,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 60.dp),
    ) {
        Row(
            Modifier.padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("${severity.level}", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(10.dp))
            Text(severity.label(language), fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
    }
}

/** Stylised body made of large tap targets; the picked area turns the colour of the chosen severity. */
@Composable
private fun BodyMap(
    view: BodyView,
    selected: PainRegion?,
    severity: PainSeverity?,
    onRegion: (PainRegion) -> Unit,
    modifier: Modifier = Modifier,
) {
    val regions = remember(view) { PainRegion.entries.filter { it.view == view } }
    val decor = if (view == BodyView.FRONT) FrontDecor else BackDecor
    val currentOnRegion by rememberUpdatedState(onRegion)
    val idle = Color(0xFF90A4AE)
    val filler = Color(0xFFCFD8DC)
    val outline = Color(0xFF263238)

    Box(modifier) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .aspectRatio(0.5f)
                .semantics { contentDescription = "Body map" }
                .pointerInput(view) {
                    detectTapGestures { o ->
                        val p = Offset(o.x / size.width, o.y / size.height)
                        regions.firstOrNull { it.bounds().contains(p) }?.let(currentOnRegion)
                    }
                }
        ) {
            decor.forEach { drawBlock(it, filler, oval = false, outline = outline) }
            regions.forEach { r ->
                val fill = when {
                    r != selected -> idle
                    severity != null -> severity.color()
                    else -> HighlightYellow
                }
                drawBlock(r.bounds(), fill, r.isOval(), outline, thick = r == selected)
            }
        }
    }
}

private fun DrawScope.drawBlock(b: Rect, fill: Color, oval: Boolean, outline: Color, thick: Boolean = false) {
    val topLeft = Offset(b.left * size.width, b.top * size.height)
    val blockSize = Size(b.width * size.width, b.height * size.height)
    val stroke = Stroke(width = if (thick) 8f else 3f)
    if (oval) {
        drawOval(fill, topLeft, blockSize)
        drawOval(outline, topLeft, blockSize, style = stroke)
    } else {
        val corner = CornerRadius(24f, 24f)
        drawRoundRect(fill, topLeft, blockSize, corner)
        drawRoundRect(outline, topLeft, blockSize, corner, style = stroke)
    }
}
