package com.mywords.domain.repository

import com.mywords.domain.model.FamilyMember
import com.mywords.domain.model.PainRegion
import com.mywords.domain.model.PainSeverity
import java.io.File
import java.io.InputStream
import kotlinx.coroutines.flow.Flow

interface FamilyRepository {
    /** Members with their photo and recorded-voice paths already resolved. */
    fun observeMembers(): Flow<List<FamilyMember>>
    suspend fun updateDetails(id: Long, spokenPhrase: String, phone: String)
    suspend fun setPhoto(id: Long, image: InputStream)
    suspend fun clearPhoto(id: Long)
    suspend fun saveRecording(key: String, file: File)
    suspend fun deleteRecording(key: String)
}

interface PainRepository {
    suspend fun log(region: PainRegion, severity: PainSeverity)
}
