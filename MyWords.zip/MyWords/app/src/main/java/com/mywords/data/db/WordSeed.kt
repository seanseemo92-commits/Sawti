package com.mywords.data.db

import com.mywords.domain.model.CategoryIds
import com.mywords.domain.model.PhonemicCue

/**
 * Built-in vocabulary. For every word:
 *   display = friendly on-screen label, tts = fully vocalised MSA for Android TTS,
 *   cue     = first-syllable prompt (derived from tts unless overridden).
 * Edit any of it later from Caregiver Mode.
 */
object WordSeed {

    data class Word(
        val display: String,
        val tts: String,
        val emoji: String = "",
        val subgroup: String = "",
        val cue: String? = null,
        val sort: Int? = null,
    )

    data class Cat(
        val id: String,
        val title: String,
        val palette: Int,
        val words: List<Word>,
        val previewOnTap: Boolean = false,
    )

    private const val HUSBAND = "الزوج"
    private const val CHILDREN = "الأبناء"
    private const val SISTERS = "الأخوات"
    private const val BROTHERS = "الإخوة"

    private fun person(sub: String, name: String, tts: String) = Word(name, tts, subgroup = sub)

    val categories: List<Cat> = listOf(
        // ---- Priority 1: family (the 21 members) ----
        Cat(
            id = CategoryIds.FAMILY, title = "عائلتي", palette = 0, previewOnTap = true,
            words = listOf(
                person(HUSBAND, "محمد", "مُحَمَّدْ"),
                person(CHILDREN, "إيمان", "إِيمَانْ"),
                person(CHILDREN, "خولة", "خَوْلَة"),
                person(CHILDREN, "إبراهيم", "إِبْرَاهِيمْ"),
                person(CHILDREN, "إسماعيل", "إِسْمَاعِيلْ"),
                person(CHILDREN, "أيوب", "أَيُّوبْ"),
                person(CHILDREN, "زكريا", "زَكَرِيَّا"),
                person(CHILDREN, "يوسف", "يُوسُفْ"),
                person(SISTERS, "جمعية", "جُمْعِيَّة"),
                person(SISTERS, "نجاة", "نَجَاة"),
                person(SISTERS, "ربيعة", "رَبِيعَة"),
                person(SISTERS, "سعاد", "سُعَادْ"),
                person(SISTERS, "زينب", "زَيْنَبْ"),
                person(BROTHERS, "الشارف", "الشَّارِفْ"),
                person(BROTHERS, "عياد", "عَيَّادْ"),
                person(BROTHERS, "عبد السلام", "عَبْدُ السَّلَامْ"),
                person(BROTHERS, "خالد", "خَالِدْ"),
                person(BROTHERS, "سعد", "سَعْدْ"),
                person(BROTHERS, "نوري", "نُورِي"),
                person(BROTHERS, "عادل", "عَادِلْ"),
                person(BROTHERS, "وليد", "وَلِيدْ"),
                // second phrase for the husband; sorted last so it stays out of the home-card collage
                Word("وين محمد؟", "أَيْنَ مُحَمَّدْ؟", emoji = "❓", subgroup = HUSBAND, sort = 100),
            ),
        ),
        // ---- Priority 2: daily expressions ----
        Cat(
            id = CategoryIds.DAILY, title = "طلباتي اليومية", palette = 1,
            words = listOf(
                Word("نبي مية", "أُرِيدُ مَاءً", "💧", cue = "مَـ..."),
                Word("نبي شاي", "أُرِيدُ شَايًا", "🍵", cue = "شَـ..."),
                Word("نبي نرتاح", "أُرِيدُ أَنْ أَرْتَاحَ", "🛋️", cue = "أَرْـ..."),
                Word("نبي دوايا", "أُرِيدُ دَوَائِي", "💊", cue = "دَـ..."),
                Word("نبي الحمام", "أُرِيدُ الذَّهَابَ إِلَى الحَمَّامِ", "🚿", cue = "حَمْـ..."),
                Word("عدّل لي المخدة", "أَرْجُو تَعْدِيلَ الوِسَادَةِ", "🛏️", cue = "تَعْـ..."),
            ),
        ),
        // ---- Educational categories ----
        Cat(
            id = "fruits", title = "الفواكه", palette = 2,
            words = listOf(
                Word("تفاحة", "تُفَّاحَة", "🍎"), Word("موزة", "مَوْزَة", "🍌"),
                Word("برتقالة", "بُرْتُقَالَة", "🍊"), Word("عنب", "عِنَب", "🍇"),
                Word("بطيخ", "بَطِّيخ", "🍉"), Word("فراولة", "فَرَاوْلَة", "🍓"),
                Word("ليمون", "لِيمُون", "🍋"), Word("كمثرى", "كُمَّثْرَى", "🍐"),
                Word("كرز", "كَرَز", "🍒"),
            ),
        ),
        Cat(
            id = "vegetables", title = "الخضروات", palette = 3,
            words = listOf(
                Word("طماطم", "طَمَاطِم", "🍅"), Word("بطاطا", "بَطَاطَا", "🥔"),
                Word("جزر", "جَزَر", "🥕"), Word("بصل", "بَصَل", "🧅"),
                Word("ثوم", "ثُوم", "🧄"), Word("خيار", "خِيَار", "🥒"),
                Word("فلفل", "فُلْفُل", "🌶️"), Word("ذرة", "ذُرَة", "🌽"),
                Word("باذنجان", "بَاذِنْجَان", "🍆"),
            ),
        ),
        Cat(
            id = "food", title = "الطعام", palette = 4,
            words = listOf(
                Word("خبز", "خُبْز", "🍞"), Word("أرز", "أَرُز", "🍚"),
                Word("لحم", "لَحْم", "🥩"), Word("دجاج", "دَجَاج", "🍗"),
                Word("سمك", "سَمَك", "🐟"), Word("بيض", "بَيْض", "🥚"),
                Word("حليب", "حَلِيب", "🥛"), Word("جبن", "جُبْن", "🧀"),
                Word("شوربة", "شُورْبَة", "🍲"),
            ),
        ),
        Cat(
            id = "clothes", title = "الملابس", palette = 5,
            words = listOf(
                Word("قميص", "قَمِيص", "👕"), Word("بنطلون", "بَنْطَلُون", "👖"),
                Word("فستان", "فُسْتَان", "👗"), Word("حذاء", "حِذَاء", "👟"),
                Word("جوارب", "جَوَارِب", "🧦"), Word("قبعة", "قُبَّعَة", "🧢"),
                Word("معطف", "مِعْطَف", "🧥"), Word("وشاح", "وِشَاح", "🧣"),
                Word("قفازات", "قُفَّازَات", "🧤"),
            ),
        ),
        Cat(
            id = "home", title = "المنزل", palette = 6,
            words = listOf(
                Word("سرير", "سَرِير", "🛏️"), Word("أريكة", "أَرِيكَة", "🛋️"),
                Word("كرسي", "كُرْسِيّ", "🪑"), Word("باب", "بَاب", "🚪"),
                Word("تلفاز", "تِلْفَاز", "📺"), Word("هاتف", "هَاتِف", "📞"),
                Word("ساعة", "سَاعَة", "⏰"), Word("مفتاح", "مِفْتَاح", "🔑"),
                Word("كوب", "كُوب", "☕"),
            ),
        ),
        Cat(
            id = "actions", title = "الأفعال", palette = 7,
            words = listOf(
                Word("آكل", "آكُل", "🍽️"), Word("أشرب", "أَشْرَب", "🥤"),
                Word("أنام", "أَنَام", "😴"), Word("أمشي", "أَمْشِي", "🚶"),
                Word("أجلس", "أَجْلِس", "🪑"), Word("أغسل", "أَغْسِل", "🧼"),
                Word("أقرأ", "أَقْرَأ", "📖"), Word("أتكلم", "أَتَكَلَّم", "🗣️"),
                Word("أضحك", "أَضْحَك", "😄"),
            ),
        ),
        Cat(
            id = "animals", title = "الحيوانات والطيور", palette = 8,
            words = listOf(
                Word("قطة", "قِطَّة", "🐱"), Word("كلب", "كَلْب", "🐶"),
                Word("حصان", "حِصَان", "🐴"), Word("بقرة", "بَقَرَة", "🐄"),
                Word("خروف", "خَرُوف", "🐑"), Word("جمل", "جَمَل", "🐪"),
                Word("دجاجة", "دَجَاجَة", "🐔"), Word("عصفور", "عُصْفُور", "🐦"),
                Word("حمامة", "حَمَامَة", "🕊️"),
            ),
        ),
        Cat(
            id = "body", title = "أجزاء الجسم", palette = 9,
            words = listOf(
                Word("رأس", "رَأْس", "🙂"), Word("عين", "عَيْن", "👁️"),
                Word("أذن", "أُذُن", "👂"), Word("أنف", "أَنْف", "👃"),
                Word("فم", "فَم", "👄"), Word("يد", "يَد", "✋"),
                Word("رجل", "رِجْل", "🦵"), Word("قلب", "قَلْب", "❤️"),
                Word("سن", "سِنّ", "🦷"),
            ),
        ),
    )

    fun categoryEntities(): List<CategoryEntity> =
        categories.mapIndexed { i, c -> CategoryEntity(c.id, c.title, c.palette, c.previewOnTap, i) }

    fun itemEntities(): List<WordItemEntity> =
        categories.flatMap { c ->
            c.words.mapIndexed { i, w ->
                WordItemEntity(
                    categoryId = c.id,
                    subgroup = w.subgroup,
                    displayText = w.display,
                    ttsPrompt = w.tts,
                    phonemicCue = w.cue ?: PhonemicCue.derive(w.tts),
                    emoji = w.emoji,
                    sortOrder = w.sort ?: i,
                )
            }
        }
}
