package com.mywords.presentation.dashboard

import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.tts.TextToSpeech
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Mic
import com.mywords.domain.model.RecordingKeys
import com.mywords.presentation.common.CaregiverLockButton
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mywords.R
import com.mywords.domain.model.AppLanguage
import com.mywords.domain.model.Category
import com.mywords.domain.model.CommunicationItem
import com.mywords.domain.model.DisplayMode
import com.mywords.presentation.theme.EmergencyRed
import com.mywords.presentation.theme.EmergencyRedDark
import com.mywords.presentation.theme.HighlightYellow
import com.mywords.presentation.theme.tileColor
import com.mywords.presentation.theme.toImageVector
import com.mywords.speech.SpeechIssue

/** Entry point: collects state and wires ViewModel callbacks. */
@Composable
fun DashboardRoute(viewModel: DashboardViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    DashboardScreen(
        state = state,
        onItemClick = viewModel::onItemTapped,
        onItemLongClick = viewModel::onItemLongPressed,
        onCaregiverToggle = viewModel::onCaregiverToggled,
        onLanguageSelected = viewModel::onLanguageSelected,
        onDisplayModeChange = viewModel::onDisplayModeChanged,
        onInstallVoice = {
            try {
                context.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
            } catch (_: ActivityNotFoundException) { /* no installer on this device */ }
        },
        editor = viewModel,
    )
}

/** Emergency bar + chime are in the shared top bar (see AppRoot); this is the content area only. */
@Composable
fun DashboardScreen(
    state: DashboardUiState,
    onItemClick: (CommunicationItem) -> Unit,
    onItemLongClick: (CommunicationItem) -> Unit,
    onCaregiverToggle: () -> Unit,
    onLanguageSelected: (AppLanguage) -> Unit,
    onDisplayModeChange: (DisplayMode) -> Unit,
    onInstallVoice: () -> Unit,
    editor: TileEditorActions,
) {
    Column(Modifier.fillMaxSize()) {
        state.speechIssue?.let { SpeechIssueBanner(it, onInstallVoice) }
        ControlsRow(
            language = state.language,
            dual = state.displayMode == DisplayMode.DUAL,
            caregiverMode = state.caregiverMode,
            onLanguageSelected = onLanguageSelected,
            onDualChange = { on ->
                onDisplayModeChange(if (on) DisplayMode.DUAL else DisplayMode.SINGLE)
            },
            onCaregiverToggle = onCaregiverToggle,
        )
        if (state.caregiverMode) {
            Text(
                stringResource(R.string.caregiver_banner_tiles),
                color = EmergencyRed,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 156.dp),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            state.categories.forEach { category ->
                item(key = "header-${category.id}", span = { GridItemSpan(maxLineSpan) }) {
                    CategoryHeader(category, state.language, state.displayMode)
                }
                items(category.items, key = { it.id }) { item ->
                    CommunicationTile(
                        item = item,
                        container = category.theme.tileColor(),
                        language = state.language,
                        displayMode = state.displayMode,
                        isActive = state.activeItemId == item.id,
                        caregiverMode = state.caregiverMode,
                        hasRecording = RecordingKeys.item(item.id, state.language) in state.recordedKeys,
                        onClick = { onItemClick(item) },
                        onLongClick = { onItemLongClick(item) },
                    )
                }
            }
        }
    }

    // Caregiver voice editor for the tapped tile.
    state.editingItemId?.let { id ->
        state.categories.flatMap { it.items }.firstOrNull { it.id == id }?.let { item ->
            EditTileDialog(
                item = item,
                language = state.language,
                hasRecording = RecordingKeys.item(item.id, state.language) in state.recordedKeys,
                isRecording = state.recordingItemId == item.id,
                editor = editor,
            )
        }
    }
}

// ---------------------------------------------------------------- Emergency

@Composable
internal fun EmergencyBar(chimeOn: Boolean, onEmergency: () -> Unit, onChime: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Button(
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onEmergency()
            },
            modifier = Modifier
                .weight(1f)
                .height(72.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EmergencyRed, contentColor = Color.White),
        ) {
            Icon(Icons.Filled.Warning, contentDescription = null, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.emergency_button),
                fontSize = 22.sp,
                lineHeight = 24.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }
        // Loud alert chime: tap to start, tap again to stop.
        Button(
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onChime()
            },
            modifier = Modifier.size(72.dp),
            shape = RoundedCornerShape(16.dp),
            contentPadding = PaddingValues(0.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (chimeOn) Color.Black else HighlightYellow,
                contentColor = if (chimeOn) HighlightYellow else Color.Black,
            ),
        ) {
            Icon(
                if (chimeOn) Icons.Filled.NotificationsOff else Icons.Filled.NotificationsActive,
                contentDescription = stringResource(if (chimeOn) R.string.alert_chime_stop else R.string.alert_chime),
                modifier = Modifier.size(40.dp),
            )
        }
    }
}

@Composable
internal fun EmergencyActiveBanner(onStop: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(EmergencyRedDark)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            stringResource(R.string.emergency_active),
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f),
        )
        Button(
            onClick = onStop,
            modifier = Modifier.heightIn(min = 56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = EmergencyRedDark),
        ) { Text(stringResource(R.string.stop), fontSize = 20.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun SpeechIssueBanner(issue: SpeechIssue, onInstall: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(HighlightYellow)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = stringResource(
                if (issue is SpeechIssue.MissingVoice) R.string.voice_missing else R.string.tts_unavailable
            ),
            color = Color.Black,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f),
        )
        if (issue is SpeechIssue.MissingVoice) {
            Button(
                onClick = onInstall,
                modifier = Modifier.heightIn(min = 48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White),
            ) { Text(stringResource(R.string.install_voice), fontSize = 16.sp) }
        }
    }
}

// ---------------------------------------------------------------- Controls

@Composable
private fun ControlsRow(
    language: AppLanguage,
    dual: Boolean,
    caregiverMode: Boolean,
    onLanguageSelected: (AppLanguage) -> Unit,
    onDualChange: (Boolean) -> Unit,
    onCaregiverToggle: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        LanguageSwitcher(language, onLanguageSelected, Modifier.weight(1f))
        DualModeToggle(dual, onDualChange)
        CaregiverLockButton(enabled = caregiverMode, onToggle = onCaregiverToggle)
    }
}

/** Two big side-by-side buttons. Labels are always shown in their own language. */
@Composable
private fun LanguageSwitcher(
    selected: AppLanguage,
    onSelected: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier,
) {
    val primary = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .height(56.dp)
            .clip(shape)
            .border(2.dp, primary, shape)
    ) {
        listOf(AppLanguage.ARABIC to "العربية", AppLanguage.ENGLISH to "English").forEach { (lang, label) ->
            val isSelected = lang == selected
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(if (isSelected) primary else Color.Transparent)
                    .selectable(selected = isSelected, role = Role.RadioButton) { onSelected(lang) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else primary,
                )
            }
        }
    }
}

/** Toggles the Arabic + English subtitle on every tile. */
@Composable
private fun DualModeToggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Box(
        Modifier
            .size(56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (on) scheme.primary else scheme.primaryContainer)
            .toggleable(value = on, role = Role.Switch, onValueChange = onChange),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Filled.Translate,
            contentDescription = stringResource(R.string.dual_language),
            tint = if (on) Color.White else scheme.onPrimaryContainer,
            modifier = Modifier.size(30.dp),
        )
    }
}

// ---------------------------------------------------------------- Grid content

@Composable
private fun CategoryHeader(category: Category, language: AppLanguage, mode: DisplayMode) {
    Column(Modifier.padding(top = 12.dp, bottom = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(8.dp)
                    .height(32.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(category.theme.tileColor())
            )
            Spacer(Modifier.width(10.dp))
            Text(
                category.title.get(language),
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
            )
        }
        if (mode == DisplayMode.DUAL) {
            Text(
                category.title.get(language.other),
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f),
                modifier = Modifier.padding(start = 18.dp),
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CommunicationTile(
    item: CommunicationItem,
    container: Color,
    language: AppLanguage,
    displayMode: DisplayMode,
    isActive: Boolean,
    caregiverMode: Boolean,
    hasRecording: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val haptic = LocalHapticFeedback.current
    val background by animateColorAsState(if (isActive) HighlightYellow else container, label = "tile-bg")
    val foreground = if (isActive) Color.Black else Color.White

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = background,
        contentColor = foreground,
        border = if (isActive) BorderStroke(4.dp, Color.Black) else null,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 156.dp)
                .combinedClickable(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onClick()
                    },
                    onLongClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onLongClick()
                    },
                ),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Icon(item.icon.toImageVector(), contentDescription = null, modifier = Modifier.size(60.dp))
                Spacer(Modifier.height(8.dp))
                Text(
                    item.label.get(language),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    lineHeight = 28.sp,
                )
                if (displayMode == DisplayMode.DUAL) {
                    Text(
                        item.label.get(language.other),
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 2.dp),
                    )
                }
            }
            // Caregiver mode: mic = has a custom voice for this language, pencil = none yet.
            if (caregiverMode) {
                Icon(
                    if (hasRecording) Icons.Filled.Mic else Icons.Filled.Edit,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(30.dp)
                        .background(EmergencyRed, CircleShape)
                        .padding(6.dp),
                )
            }
        }
    }
}
