package com.mywords.data

import android.content.Context
import com.mywords.domain.model.DisplayMode

/** Tiny persistence for the single/dual display preference (language is stored by AppCompat). */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("my_words_settings", Context.MODE_PRIVATE)

    var displayMode: DisplayMode
        get() = runCatching { DisplayMode.valueOf(prefs.getString(KEY_DISPLAY, null) ?: "") }
            .getOrDefault(DisplayMode.SINGLE)
        set(value) = prefs.edit().putString(KEY_DISPLAY, value.name).apply()

    private companion object { const val KEY_DISPLAY = "display_mode" }
}
