package com.mywords.data.db

import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.mywords.domain.model.FamilyGroup
import com.mywords.domain.model.FamilyGroup.BROTHERS
import com.mywords.domain.model.FamilyGroup.CHILDREN
import com.mywords.domain.model.FamilyGroup.HUSBAND
import com.mywords.domain.model.FamilyGroup.SISTERS

/** The exact family list, in display order. Phrases are Libyan dialect ("نبي" = I want). */
object FamilySeed {

    data class Seed(
        val group: FamilyGroup,
        val name: String,
        val phrase: String,
        val altPhrase: String? = null,
    )

    val members: List<Seed> =
        listOf(Seed(HUSBAND, "محمد", "نبي محمد", altPhrase = "وين محمد؟")) +
            listOf("إيمان", "خولة", "إبراهيم", "إسماعيل", "أيوب", "زكريا", "يوسف")
                .map { Seed(CHILDREN, it, "نبي $it") } +
            listOf("جمعية", "نجاة", "ربيعة", "سعاد", "زينب")
                .map { Seed(SISTERS, it, "نبي أختي $it") } +
            listOf("الشارف", "عياد", "عبد السلام", "خالد", "سعد", "نوري", "عادل", "وليد")
                .map { Seed(BROTHERS, it, "نبي خوي $it") }
}

/**
 * Runs once, when the database file is first created (before any DAO is used),
 * so the family is there on first launch. Plain SQL avoids a circular dependency
 * on the database instance. To re-test: uninstall the app or clear its storage.
 */
object FamilySeedCallback : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        FamilySeed.members.forEachIndexed { index, m ->
            db.execSQL(
                "INSERT INTO family_members " +
                    "(relation, name, spokenPhrase, altPhrase, phone, photoPath, sortOrder) " +
                    "VALUES (?, ?, ?, ?, '', NULL, ?)",
                arrayOf<Any?>(m.group.name, m.name, m.phrase, m.altPhrase, index),
            )
        }
    }
}
