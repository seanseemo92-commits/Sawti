package com.mywords.domain.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Card text scaling: Normal / Large / Extra Large. */
enum class TextSize(val factor: Float) { NORMAL(1f), LARGE(1.2f), EXTRA_LARGE(1.4f) }

/** TTS speaking speed. */
enum class SpeechRate(val factor: Float) { SLOW(0.75f), NORMAL(0.85f), FAST(1.0f) }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val textSize: TextSize = TextSize.NORMAL,
    val speechRate: SpeechRate = SpeechRate.NORMAL,
    val hapticsEnabled: Boolean = true,
    /** "وضع الأداء السلس": no spring/alpha animations or shadows, smaller decoded images. */
    val performanceMode: Boolean = false,
)
