package com.mywords.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.mywords.domain.model.FamilyGroup
import com.mywords.domain.model.FamilyMember

@Entity(tableName = "family_members")
data class FamilyMemberEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val relation: FamilyGroup,          // stored as TEXT (enum name)
    val name: String,
    val spokenPhrase: String,
    val altPhrase: String? = null,
    val phone: String = "",
    val photoPath: String? = null,      // copy of the gallery photo inside app storage
    val sortOrder: Int = 0,
)

/** One caregiver recording per key (see RecordingKeys). */
@Entity(tableName = "voice_recordings")
data class VoiceRecordingEntity(
    @PrimaryKey val recordingKey: String,
    val filePath: String,
)

/** Small history the caregiver/doctor can review later. */
@Entity(tableName = "pain_reports")
data class PainReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val regionKey: String,
    val severity: Int,
    val timestamp: Long,
)

fun FamilyMemberEntity.toDomain(voicePath: String?) = FamilyMember(
    id = id, group = relation, name = name, spokenPhrase = spokenPhrase,
    altPhrase = altPhrase, phone = phone, photoPath = photoPath, voicePath = voicePath,
)
