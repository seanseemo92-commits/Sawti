package com.mywords.locale

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.mywords.domain.model.AppLanguage

/**
 * Per-app language switching. Calling [apply] recreates the activity; Compose then
 * picks up the new configuration and mirrors the whole layout for RTL automatically
 * (requires android:supportsRtl="true" in the manifest).
 */
object LocaleManager {

    fun apply(language: AppLanguage) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(language.tag))
    }

    fun current(context: Context): AppLanguage {
        val appLocales = AppCompatDelegate.getApplicationLocales()
        val tag = if (!appLocales.isEmpty) {
            appLocales[0]?.language
        } else {
            context.resources.configuration.locales[0].language
        }
        return AppLanguage.fromTag(tag)
    }
}
