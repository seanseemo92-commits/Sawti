package com.mywords.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WordDao {
    @Query("SELECT * FROM categories ORDER BY sortOrder")
    fun observeCategories(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM word_items ORDER BY sortOrder, id")
    fun observeItems(): Flow<List<WordItemEntity>>

    @Query("SELECT COUNT(*) FROM categories")
    suspend fun categoryCount(): Int

    @Insert
    suspend fun insertCategories(categories: List<CategoryEntity>)

    @Insert
    suspend fun insertItems(items: List<WordItemEntity>)

    @Query(
        "UPDATE word_items SET displayText = :display, ttsPrompt = :tts, " +
            "phonemicCue = :cue, phone = :phone WHERE id = :id"
    )
    suspend fun updateDetails(id: Long, display: String, tts: String, cue: String, phone: String)

    @Query("SELECT photoPath FROM word_items WHERE id = :id")
    suspend fun photoPath(id: Long): String?

    @Query("UPDATE word_items SET photoPath = :path WHERE id = :id")
    suspend fun updatePhoto(id: Long, path: String?)

    @Query("SELECT audioPath FROM word_items WHERE id = :id")
    suspend fun audioPath(id: Long): String?

    @Query("UPDATE word_items SET audioPath = :path WHERE id = :id")
    suspend fun updateAudio(id: Long, path: String?)
}
