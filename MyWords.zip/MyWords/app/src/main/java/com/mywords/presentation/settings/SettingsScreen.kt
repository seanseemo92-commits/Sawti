package com.mywords.presentation.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mywords.R
import com.mywords.domain.model.SpeechRate
import com.mywords.domain.model.TextSize
import com.mywords.domain.model.ThemeMode
import com.mywords.presentation.theme.AppBarBlue
import com.mywords.presentation.theme.cardElevation

/** Caregiver-only display settings: theme, card text size and Performance Mode. */
@Composable
fun SettingsRoute(viewModel: SettingsViewModel) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        SettingBlock(stringResource(R.string.settings_theme)) {
            ChoiceRow(
                options = listOf(
                    ThemeMode.SYSTEM to stringResource(R.string.theme_system),
                    ThemeMode.LIGHT to stringResource(R.string.theme_light),
                    ThemeMode.DARK to stringResource(R.string.theme_dark),
                ),
                selected = settings.themeMode,
                onSelect = viewModel::setThemeMode,
            )
        }
        SettingBlock(stringResource(R.string.settings_text_size)) {
            ChoiceRow(
                options = listOf(
                    TextSize.NORMAL to stringResource(R.string.size_normal),
                    TextSize.LARGE to stringResource(R.string.size_large),
                    TextSize.EXTRA_LARGE to stringResource(R.string.size_xlarge),
                ),
                selected = settings.textSize,
                onSelect = viewModel::setTextSize,
            )
        }
        SettingBlock(stringResource(R.string.settings_speech_rate)) {
            ChoiceRow(
                options = listOf(
                    SpeechRate.SLOW to stringResource(R.string.rate_slow),
                    SpeechRate.NORMAL to stringResource(R.string.rate_normal),
                    SpeechRate.FAST to stringResource(R.string.rate_fast),
                ),
                selected = settings.speechRate,
                onSelect = viewModel::setSpeechRate,
            )
        }
        SettingBlock(stringResource(R.string.settings_haptics)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.settings_haptics_desc),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = settings.hapticsEnabled, onCheckedChange = viewModel::setHapticsEnabled)
            }
        }
        SettingBlock(stringResource(R.string.settings_performance)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.settings_performance_desc),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                Switch(checked = settings.performanceMode, onCheckedChange = viewModel::setPerformanceMode)
            }
        }
    }
}

@Composable
private fun SettingBlock(title: String, content: @Composable () -> Unit) {
    Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = cardElevation(2.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = AppBarBlue)
            content()
        }
    }
}

@Composable
private fun <T> ChoiceRow(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            val on = value == selected
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = if (on) AppBarBlue else MaterialTheme.colorScheme.surfaceVariant,
                contentColor = if (on) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .clickable { onSelect(value) },
            ) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Text(label, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                }
            }
        }
    }
}
