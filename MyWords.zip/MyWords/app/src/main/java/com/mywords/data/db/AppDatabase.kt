package com.mywords.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [FamilyMemberEntity::class, VoiceRecordingEntity::class, PainReportEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun familyDao(): FamilyDao
    abstract fun voiceDao(): VoiceDao
    abstract fun painDao(): PainDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "my_words.db")
                .addCallback(FamilySeedCallback)
                .build()
    }
}
