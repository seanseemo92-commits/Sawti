package com.mywords

import android.app.Application
import com.mywords.audio.AlertChime
import com.mywords.audio.AudioPlayer
import com.mywords.audio.VoiceRecorder
import com.mywords.data.RoomFamilyRepository
import com.mywords.data.RoomPainRepository
import com.mywords.data.RoomVoiceRepository
import com.mywords.data.db.AppDatabase
import com.mywords.domain.repository.FamilyRepository
import com.mywords.domain.repository.PainRepository
import com.mywords.domain.repository.VoiceRepository
import com.mywords.state.CaregiverMode
import com.mywords.speech.SpeechManager

/** Hand-rolled DI: one shared instance of everything the ViewModels need. Swap for Hilt if you prefer. */
class AppContainer(private val app: Application) {
    val database by lazy { AppDatabase.build(app) }
    val speech by lazy { SpeechManager(app) }
    val chime by lazy { AlertChime(app) }
    val player by lazy { AudioPlayer() }
    val recorder by lazy { VoiceRecorder(app) }
    val caregiver = CaregiverMode()
    val voiceRepository: VoiceRepository by lazy { RoomVoiceRepository(database.voiceDao()) }
    val familyRepository: FamilyRepository by lazy {
        RoomFamilyRepository(app, database.familyDao(), voiceRepository)
    }
    val painRepository: PainRepository by lazy { RoomPainRepository(database.painDao()) }
}

class MyWordsApp : Application() {
    val container by lazy { AppContainer(this) }
}
