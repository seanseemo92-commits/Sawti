package com.mywords

import android.app.Application
import com.mywords.audio.AudioPlayer
import com.mywords.audio.SoftChime
import com.mywords.audio.VoiceRecorder
import com.mywords.audio.AudioDispatcher
import com.mywords.data.RoomProgressRepository
import com.mywords.data.SettingsRepository
import com.mywords.data.RoomWordRepository
import com.mywords.data.db.AppDatabase
import com.mywords.domain.repository.ProgressRepository
import com.mywords.domain.repository.WordRepository
import com.mywords.speech.SpeechManager
import com.mywords.state.CaregiverMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** Hand-rolled DI: one shared instance of everything the ViewModels need. Swap for Hilt if you prefer. */
class AppContainer(private val app: Application) {
    val database by lazy { AppDatabase.build(app) }
    val speech by lazy { SpeechManager(app) }
    val player by lazy { AudioPlayer() }
    val recorder by lazy { VoiceRecorder(app) }
    val audioDispatcher by lazy { AudioDispatcher(speech, player) }
    val caregiver = CaregiverMode()
    val wordRepository: WordRepository by lazy { RoomWordRepository(database, app) }
    val progressRepository: ProgressRepository by lazy { RoomProgressRepository(database.progressDao()) }
    val chime by lazy { SoftChime() }
    val settingsRepository by lazy { SettingsRepository(app) }
}

class MyWordsApp : Application() {
    val container by lazy { AppContainer(this) }
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        // First run (or after a schema upgrade): insert the 21 family members + all categories.
        appScope.launch { container.wordRepository.seedOrUpdateDefaults() }
        // keep the TTS speed in sync with the caregiver setting
        appScope.launch {
            container.settingsRepository.state
                .map { it.speechRate.factor }
                .distinctUntilChanged()
                .collect { container.speech.setSpeechRate(it) }
        }
    }
}
