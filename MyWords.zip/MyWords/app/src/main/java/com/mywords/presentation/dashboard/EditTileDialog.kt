package com.mywords.presentation.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mywords.R
import com.mywords.domain.model.AppLanguage
import com.mywords.domain.model.CommunicationItem
import com.mywords.presentation.common.VoiceRecordingSection

/** Caregiver editor for one dashboard tile: record, play and delete the custom voice for the current language. */
@Composable
fun EditTileDialog(
    item: CommunicationItem,
    language: AppLanguage,
    hasRecording: Boolean,
    isRecording: Boolean,
    editor: TileEditorActions,
) {
    val languageName = if (language == AppLanguage.ARABIC) "العربية" else "English"
    AlertDialog(
        onDismissRequest = editor::closeEditor,
        title = { Text(item.label.get(language), fontSize = 26.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text(stringResource(R.string.recording_for, languageName), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("“${item.spoken.get(language)}”", fontSize = 20.sp)
                VoiceRecordingSection(
                    hasRecording = hasRecording,
                    isRecording = isRecording,
                    onStart = { editor.startRecording(item.id) },
                    onStop = { editor.stopRecording(item.id) },
                    onPlay = { editor.previewRecording(item.id) },
                    onDelete = { editor.deleteRecording(item.id) },
                )
            }
        },
        confirmButton = {
            Button(onClick = editor::closeEditor, modifier = Modifier.heightIn(min = 52.dp)) {
                Text(stringResource(R.string.done), fontSize = 18.sp)
            }
        },
    )
}
