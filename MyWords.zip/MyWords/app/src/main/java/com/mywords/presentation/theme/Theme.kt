package com.mywords.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.BlurCircular
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FamilyRestroom
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Healing
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.SentimentSatisfied
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Wc
import androidx.compose.material.icons.filled.Whatshot
import com.mywords.domain.model.CategoryTheme
import com.mywords.domain.model.SymbolIcon

// Deep, saturated tiles with white text (all ≥ 7:1 contrast). Pressed state flips to
// bright yellow with black text, which is unmistakable even with low vision.
val NavyBlue = Color(0xFF0B3C5D)
val DeepPurple = Color(0xFF4A2C7A)
val BurntOrange = Color(0xFF7A3E00)
val ForestGreen = Color(0xFF1B5E20)
val EmergencyRed = Color(0xFFB71C1C)
val EmergencyRedDark = Color(0xFF7F0000)
val HighlightYellow = Color(0xFFFFD600)

fun CategoryTheme.tileColor(): Color = when (this) {
    CategoryTheme.NEEDS -> NavyBlue
    CategoryTheme.FEELINGS -> DeepPurple
    CategoryTheme.PEOPLE -> BurntOrange
    CategoryTheme.RESPONSES -> ForestGreen
}

fun SymbolIcon.toImageVector(): ImageVector = when (this) {
    SymbolIcon.WATER -> Icons.Filled.WaterDrop
    SymbolIcon.FOOD -> Icons.Filled.Restaurant
    SymbolIcon.BATHROOM -> Icons.Filled.Wc
    SymbolIcon.HELP -> Icons.Filled.PanTool
    SymbolIcon.MEDICINE -> Icons.Filled.Medication
    SymbolIcon.SLEEP -> Icons.Filled.Bedtime
    SymbolIcon.HOT -> Icons.Filled.Whatshot
    SymbolIcon.COLD -> Icons.Filled.AcUnit
    SymbolIcon.TIRED -> Icons.Filled.BatteryAlert
    SymbolIcon.PAIN -> Icons.Filled.Healing
    SymbolIcon.DIZZY -> Icons.Filled.BlurCircular
    SymbolIcon.BETTER -> Icons.Filled.SentimentSatisfied
    SymbolIcon.FAMILY -> Icons.Filled.FamilyRestroom
    SymbolIcon.DOCTOR -> Icons.Filled.MedicalServices
    SymbolIcon.NURSE -> Icons.Filled.LocalHospital
    SymbolIcon.YES -> Icons.Filled.CheckCircle
    SymbolIcon.NO -> Icons.Filled.Cancel
    SymbolIcon.THANKS -> Icons.Filled.Favorite
    SymbolIcon.WAIT -> Icons.Filled.HourglassTop
}

private val LightScheme = lightColorScheme(
    primary = NavyBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E6F2),
    onPrimaryContainer = Color(0xFF001E31),
    background = Color(0xFFFAFAFA),
    onBackground = Color(0xFF101010),
    surface = Color(0xFFFAFAFA),
    onSurface = Color(0xFF101010),
    error = EmergencyRed,
)

@Composable
fun MyWordsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightScheme, content = content)
}
