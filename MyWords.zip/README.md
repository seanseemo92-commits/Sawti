# كلماتي - My Words (v3)

Word-retrieval AAC / speech-therapy app: Kotlin, Jetpack Compose (Material 3), Room, Android TTS.

## Build
- Android Studio Ladybug (2024.2) or newer, JDK 17.
- Gradle **8.9** (see `gradle/wrapper/gradle-wrapper.properties`), AGP 8.7.3, Kotlin 2.0.21, KSP 2.0.21-1.0.28.
- Open the `MyWords` folder, let Gradle sync, run on a device (minSdk 24).
- The wrapper JAR/scripts are not included (binary). Android Studio uses the properties file directly;
  for the command line run `gradle wrapper --gradle-version 8.9` once.
- Upgrading over an earlier build: uninstall first (database schema v2 recreates the tables).

## Using it
- Arabic TTS needs Arabic voice data (Google Speech Services). A banner offers to install it.
- Gear icon in the blue bar: hold 3 seconds to enter/leave Caregiver Mode.
- Caregiver Mode: tap any card to edit its text / TTS / cue, attach a gallery photo, set a phone number
  (family cards) and record a real voice that replaces the robotic TTS.
- Until photos are attached, cards show built-in emoji (family cards show the first letter).
- 💡 on a card speaks only the phonemic cue (first syllable).
