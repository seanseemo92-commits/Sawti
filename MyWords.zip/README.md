# كلماتي - My Words (v3.2)

Word-retrieval AAC / speech-therapy app: Kotlin 2.0.21, Jetpack Compose (Material 3), Room 2.6.1, Android TTS.

## Build
- Android Studio Ladybug (2024.2) or newer, JDK 17.
- Gradle **8.9** (`gradle/wrapper/gradle-wrapper.properties`), AGP 8.7.3, KSP 2.0.21-1.0.28, compileSdk 35, minSdk 24.
- Open the project folder, let Gradle sync, run. The wrapper JAR/scripts are binary and not included:
  Android Studio uses the properties file directly; for the command line run `gradle wrapper --gradle-version 8.9` once.

## Data safety
- Room schema v3. Migrations: `MIGRATION_1_2` (keeps family members, photos, phones, recordings) and `MIGRATION_2_3`
  (ALTER/CREATE only). There is no destructive fallback anywhere.
- Room's `onCreate` does not run on upgrades, so `WordRepository.seedOrUpdateDefaults()` runs at every start:
  it seeds a fresh install, and on upgrade adds new categories/words, renames old default words in place to the Libyan
  names, fills missing sentence prompts and fixes TTS endings - never touching photoPath, audioPath, phone or custom words.

## Audio
- One `AudioDispatcher` (TTS + MediaPlayer) owned by the Application: every new sound stops the previous one.
- TTS: Locale("ar") with ar-SA / ar-EG / ar-AE / ar-JO fallbacks, then any installed Arabic voice; never crashes or mutes.
- Picked or recorded audio is stored in `filesDir/custom_audio/` (absolute path in `audioPath`).
- Every `ttsPrompt` ends with sukun, or ه + sukun for taa marbuta (no I'rab). Words ending in alef/alef-maqsura or a shadda keep that ending.

## Caregiver Mode
Hold the gear 3 seconds. Then: edit cards (text, TTS, cues, photo, phone, voice), pin favourites (star, max 8),
open "متابعة التقدم" (private progress) and "الإعدادات" (theme, card text size, speech rate, haptics, Performance Mode).


## Audit hardening notes

- Automatic vocabulary updates preserve unmatched rows; review/delete obsolete words manually instead of risking caregiver data loss.
- Photo/audio replacements stage files before updating database references and clear database references before deleting old files.
- Caregiver phone numbers, photos, recordings, and progress are configured as local-only by disabling Android backup (`allowBackup=false`). If device backup is a product requirement, define and test an explicit backup/transfer policy before changing this.
- Include the Gradle wrapper scripts and wrapper JAR in source control for reproducible builds; this archive did not include them.
- Validate the release with the project’s Android SDK/JDK environment and migration/device tests; source edits alone do not prove a successful build.
