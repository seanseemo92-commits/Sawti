package com.mywords.presentation.practice

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mywords.R
import com.mywords.presentation.common.ActionPill
import com.mywords.presentation.common.HintButton
import com.mywords.presentation.common.ItemImage
import com.mywords.presentation.theme.AppBarBlue
import com.mywords.presentation.theme.HintAmber
import com.mywords.presentation.theme.paletteOf

@Composable
fun PracticeRoute(viewModel: PracticeViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    PracticeScreen(
        state = state,
        onHint = viewModel::hint,
        onReveal = viewModel::reveal,
        onKnown = viewModel::known,
        onNext = viewModel::next,
        onRestart = viewModel::restart,
    )
}

@Composable
fun PracticeScreen(
    state: PracticeUiState,
    onHint: () -> Unit,
    onReveal: () -> Unit,
    onKnown: () -> Unit,
    onNext: () -> Unit,
    onRestart: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        when {
            !state.ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }

            state.total == 0 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.practice_empty), fontSize = 20.sp, textAlign = TextAlign.Center)
            }

            state.finished -> Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text("🌟", fontSize = 96.sp)
                Text(stringResource(R.string.practice_done), fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = AppBarBlue)
                Text(
                    stringResource(R.string.practice_score, state.score, state.total),
                    fontSize = 22.sp,
                    modifier = Modifier.padding(vertical = 16.dp),
                    textAlign = TextAlign.Center,
                )
                ActionPill(
                    label = stringResource(R.string.practice_restart),
                    icon = Icons.Filled.Refresh,
                    color = AppBarBlue,
                    onClick = onRestart,
                )
            }

            else -> {
                val card = state.card ?: return@Column
                val palette = paletteOf(card.palette)

                LinearProgressIndicator(
                    progress = { (state.index + 1f) / state.total },
                    color = palette.banner,
                    trackColor = palette.pastel,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp)),
                )
                Text("${state.index + 1} / ${state.total}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)

                Surface(
                    shape = RoundedCornerShape(32.dp),
                    color = Color.White,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        ItemImage(
                            item = card.item,
                            accent = palette.banner,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(palette.pastel)
                                .padding(20.dp),
                            crop = card.item.photoPath != null,
                            glyphScale = 0.6f,
                        )
                        Text(
                            text = if (state.revealed) card.item.displayText else stringResource(R.string.practice_prompt),
                            color = palette.banner,
                            fontSize = if (state.revealed) 38.sp else 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(16.dp),
                        )
                    }
                }

                if (!state.revealed) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        HintButton(onClick = onHint, size = 64)
                        ActionPill(
                            label = stringResource(R.string.practice_reveal),
                            icon = Icons.Filled.Visibility,
                            color = palette.banner,
                            onClick = onReveal,
                        )
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ActionPill(
                            label = stringResource(R.string.practice_known),
                            icon = Icons.Filled.Check,
                            color = palette.banner,
                            onClick = onKnown,
                        )
                        ActionPill(
                            label = stringResource(R.string.practice_next),
                            icon = Icons.AutoMirrored.Filled.ArrowBack,
                            color = HintAmber,
                            onClick = onNext,
                        )
                    }
                }
            }
        }
    }
}
