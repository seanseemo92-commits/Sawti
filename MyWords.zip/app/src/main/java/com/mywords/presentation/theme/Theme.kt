package com.mywords.presentation.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp

val AppBarBlue = Color(0xFF1E88E5)
val Ink = Color(0xFF1B2430)
val Canvas = Color(0xFFF4F7FB)
val HintAmber = Color(0xFFF59E0B)
val RecordRed = Color(0xFFC62828)
val CaregiverTint = Color(0xFFFFF3CD)
val CaregiverInk = Color(0xFF7A5200)

/** Soft pastel background + solid banner colour (white text is ≥ 4.5:1 on every banner). */
@Immutable
data class CategoryPalette(val pastel: Color, val banner: Color)

private val Palettes = listOf(
    CategoryPalette(Color(0xFFFCE4EC), Color(0xFFD81B60)), // 0 family
    CategoryPalette(Color(0xFFE0F2F1), Color(0xFF00796B)), // 1 daily
    CategoryPalette(Color(0xFFFBE9E7), Color(0xFFD84315)), // 2 fruits
    CategoryPalette(Color(0xFFE8F5E9), Color(0xFF388E3C)), // 3 vegetables
    CategoryPalette(Color(0xFFFFF3E0), Color(0xFFE65100)), // 4 food
    CategoryPalette(Color(0xFFF3E5F5), Color(0xFF7B1FA2)), // 5 clothes
    CategoryPalette(Color(0xFFEFEBE9), Color(0xFF5D4037)), // 6 home
    CategoryPalette(Color(0xFFE8EAF6), Color(0xFF3949AB)), // 7 actions
    CategoryPalette(Color(0xFFF9FBE7), Color(0xFF827717)), // 8 animals
    CategoryPalette(Color(0xFFE0F7FA), Color(0xFF00838F)), // 9 body
)

fun paletteOf(index: Int): CategoryPalette = Palettes[index.mod(Palettes.size)]

private val Scheme = lightColorScheme(
    primary = AppBarBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E9FB),
    onPrimaryContainer = Color(0xFF0B3A66),
    background = Canvas,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFE6ECF4),
    onSurfaceVariant = Color(0xFF45515F),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

/** The app is Arabic-first, so the whole UI is laid out right-to-left regardless of the phone's language. */
@Composable
fun MyWordsTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = Scheme,
            typography = Typography(),
            shapes = AppShapes,
            content = content,
        )
    }
}
