package com.mywords.presentation.category

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mywords.MyWordsApp
import com.mywords.audio.AudioPlayer
import com.mywords.audio.VoiceRecorder
import com.mywords.audio.WordVoice
import com.mywords.domain.model.Category
import com.mywords.domain.model.PhonemicCue
import com.mywords.domain.model.WordItem
import com.mywords.domain.repository.WordRepository
import com.mywords.speech.SpeechIssue
import com.mywords.speech.SpeechManager
import com.mywords.state.CaregiverMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class LibraryUiState(
    val categories: List<Category> = emptyList(),
    val caregiverMode: Boolean = false,
    val activeItemId: Long? = null,     // card highlighted after a tap
    val previewItemId: Long? = null,    // family member shown in the large-photo dialog
    val editingItemId: Long? = null,    // card shown in the caregiver editor
    val recordingItemId: Long? = null,  // card whose voice is being recorded right now
    val speechIssue: SpeechIssue? = null,
)

/** Everything the category screens can ask for. */
interface LibraryActions {
    fun onItemTapped(item: WordItem, flashcard: Boolean)
    fun onItemLongPressed(item: WordItem)
    fun onHint(item: WordItem)
    fun onSpeakAgain(item: WordItem)
    fun closePreview()
    fun closeEditor()
    fun saveDetails(id: Long, displayText: String, ttsPrompt: String, cue: String, phone: String)
    fun onPhotoPicked(itemId: Long, uri: Uri)
    fun removePhoto(itemId: Long)
    fun startRecording(itemId: Long)
    fun stopRecording(itemId: Long)
    fun previewRecording(itemId: Long)
    fun deleteRecording(itemId: Long)
}

class LibraryViewModel(
    private val repository: WordRepository,
    private val speech: SpeechManager,
    private val voice: WordVoice,
    private val player: AudioPlayer,
    private val recorder: VoiceRecorder,
    private val resolver: ContentResolver,
    private val caregiver: CaregiverMode,
) : ViewModel(), LibraryActions {

    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()

    private var highlightJob: Job? = null
    private var lastTap: Pair<String, Long>? = null

    init {
        viewModelScope.launch {
            repository.observeCategories().collect { list -> _uiState.update { it.copy(categories = list) } }
        }
        viewModelScope.launch {
            caregiver.enabled.collect { on ->
                _uiState.update {
                    it.copy(
                        caregiverMode = on,
                        editingItemId = if (on) it.editingItemId else null,
                        previewItemId = if (on) null else it.previewItemId,
                    )
                }
            }
        }
        viewModelScope.launch {
            speech.issue.collect { issue -> _uiState.update { it.copy(speechIssue = issue) } }
        }
    }

    fun toggleCaregiver() = caregiver.toggle()

    // ---- Speaking -------------------------------------------------------

    override fun onItemTapped(item: WordItem, flashcard: Boolean) {
        val state = _uiState.value
        if (state.caregiverMode) {
            _uiState.update { it.copy(editingItemId = item.id) }
            return
        }
        if (isRepeat("t${item.id}")) return

        voice.play(item)
        highlight(item.id)

        // Family: show the photo large while the name is spoken.
        val previewOnTap = state.categories.firstOrNull { it.id == item.categoryId }?.previewOnTap == true
        if (previewOnTap && !flashcard) _uiState.update { it.copy(previewItemId = item.id) }
    }

    override fun onItemLongPressed(item: WordItem) {
        if (_uiState.value.caregiverMode) _uiState.update { it.copy(editingItemId = item.id) }
    }

    override fun onHint(item: WordItem) {
        if (isRepeat("h${item.id}")) return
        voice.hint(item)
    }

    override fun onSpeakAgain(item: WordItem) = voice.play(item)

    override fun closePreview() {
        voice.stop()
        _uiState.update { it.copy(previewItemId = null) }
    }

    /** Ignores accidental double-taps (tremor) on the same control. */
    private fun isRepeat(key: String): Boolean {
        val now = SystemClock.elapsedRealtime()
        lastTap?.let { (k, t) -> if (k == key && now - t < DEBOUNCE_MS) return true }
        lastTap = key to now
        return false
    }

    private fun highlight(id: Long) {
        highlightJob?.cancel()
        _uiState.update { it.copy(activeItemId = id) }
        highlightJob = viewModelScope.launch {
            delay(HIGHLIGHT_MS)
            _uiState.update { it.copy(activeItemId = null) }
        }
    }

    // ---- Caregiver editor ----------------------------------------------

    override fun closeEditor() {
        recorder.cancel()
        voice.stop()
        _uiState.update { it.copy(editingItemId = null, recordingItemId = null) }
    }

    override fun saveDetails(id: Long, displayText: String, ttsPrompt: String, cue: String, phone: String) {
        val current = find(id) ?: return
        val finalDisplay = displayText.ifBlank { current.displayText }
        val finalTts = ttsPrompt.ifBlank { current.ttsPrompt }
        val finalCue = cue.ifBlank { PhonemicCue.derive(finalTts) }
        viewModelScope.launch {
            repository.updateDetails(id, finalDisplay, finalTts, finalCue, phone)
            closeEditor()
        }
    }

    override fun onPhotoPicked(itemId: Long, uri: Uri) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { resolver.openInputStream(uri) }
                ?.let { repository.setPhoto(itemId, it) }
        }
    }

    override fun removePhoto(itemId: Long) {
        viewModelScope.launch { repository.clearPhoto(itemId) }
    }

    /** The UI must have RECORD_AUDIO granted before calling this. */
    override fun startRecording(itemId: Long) {
        voice.stop()
        if (recorder.start("word_$itemId")) _uiState.update { it.copy(recordingItemId = itemId) }
    }

    override fun stopRecording(itemId: Long) {
        val file = recorder.stop()
        _uiState.update { it.copy(recordingItemId = null) }
        if (file != null) viewModelScope.launch { repository.setAudio(itemId, file) }
    }

    override fun previewRecording(itemId: Long) {
        find(itemId)?.audioPath?.let { player.play(it) }
    }

    override fun deleteRecording(itemId: Long) {
        player.stop()
        viewModelScope.launch { repository.clearAudio(itemId) }
    }

    private fun find(id: Long): WordItem? =
        _uiState.value.categories.firstNotNullOfOrNull { c -> c.items.firstOrNull { it.id == id } }

    override fun onCleared() {
        recorder.cancel()
    }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val c = (app as MyWordsApp).container
            return LibraryViewModel(
                c.wordRepository, c.speech, c.wordVoice, c.player, c.recorder, app.contentResolver, c.caregiver,
            ) as T
        }
    }

    private companion object {
        const val DEBOUNCE_MS = 500L
        const val HIGHLIGHT_MS = 1200L
    }
}
