package com.mywords.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mywords.domain.model.Category
import com.mywords.presentation.common.ItemImage
import com.mywords.presentation.common.bounceClick
import com.mywords.presentation.theme.CategoryPalette
import com.mywords.presentation.theme.paletteOf

/** 2-column category grid. The first two cards are always عائلتي and طلباتي اليومية. */
@Composable
fun HomeScreen(categories: List<Category>, onOpen: (String) -> Unit) {
    if (categories.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 28.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        items(categories, key = { it.id }) { category ->
            CategoryCard(category) { onOpen(category.id) }
        }
    }
}

@Composable
private fun CategoryCard(category: Category, onClick: () -> Unit) {
    val palette = paletteOf(category.palette)
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = palette.pastel,
        shadowElevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .height(204.dp)
            .bounceClick(onClick = onClick),
    ) {
        Column {
            Montage(category, palette, Modifier.weight(1f).padding(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .background(palette.banner),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = category.title,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                )
            }
        }
    }
}

/** 3×3 mini collage of the category's first nine pictures (photos once attached, emoji until then). */
@Composable
private fun Montage(category: Category, palette: CategoryPalette, modifier: Modifier = Modifier) {
    val items = category.items.take(9)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        repeat(3) { row ->
            Row(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                repeat(3) { col ->
                    val item = items.getOrNull(row * 3 + col)
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White.copy(alpha = 0.78f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (item != null) {
                            ItemImage(
                                item = item,
                                accent = palette.banner,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(2.dp),
                                crop = category.previewOnTap,
                                glyphScale = 0.62f,
                            )
                        }
                    }
                }
            }
        }
    }
}
