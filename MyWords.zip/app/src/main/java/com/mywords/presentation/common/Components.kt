@file:OptIn(ExperimentalFoundationApi::class)

package com.mywords.presentation.common

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mywords.R
import com.mywords.domain.model.WordItem
import com.mywords.presentation.theme.HintAmber
import com.mywords.presentation.theme.RecordRed
import java.io.File

/** Spring "bounce" on press + haptic tick; the card squeezes in and springs back. */
fun Modifier.bounceClick(onLongClick: (() -> Unit)? = null, onClick: () -> Unit): Modifier = composed {
    val haptic = LocalHapticFeedback.current
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "bounce",
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }.combinedClickable(
        interactionSource = source,
        indication = null,
        onLongClick = onLongClick?.let { long ->
            {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                long()
            }
        },
        onClick = {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        },
    )
}

/**
 * Picture for a word: attached photo → built-in emoji → first letter.
 * [crop] fills the frame (portraits); otherwise the image is fitted (cut-out style).
 */
@Composable
fun ItemImage(
    item: WordItem,
    accent: Color,
    modifier: Modifier = Modifier,
    crop: Boolean = false,
    glyphScale: Float = 0.55f,
) {
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val side = minOf(maxWidth, maxHeight)
        val glyphSize = with(LocalDensity.current) { (side * glyphScale).toSp() }
        val photo = item.photoPath
        when {
            photo != null -> AsyncImage(
                model = File(photo),
                contentDescription = item.displayText,
                contentScale = if (crop) ContentScale.Crop else ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp)),
            )
            item.emoji.isNotBlank() -> Text(item.emoji, fontSize = glyphSize)
            else -> Text(
                item.displayText.take(1),
                fontSize = glyphSize,
                fontWeight = FontWeight.ExtraBold,
                color = accent,
            )
        }
    }
}

/** Small, subtle 💡 button: speaks only the phonemic cue. */
@Composable
fun HintButton(onClick: () -> Unit, modifier: Modifier = Modifier, size: Int = 44) {
    val haptic = LocalHapticFeedback.current
    Box(
        modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.9f))
            .clickable {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            Icons.Outlined.Lightbulb,
            contentDescription = stringResource(R.string.hint_button),
            tint = HintAmber,
            modifier = Modifier.size((size * 0.55f).dp),
        )
    }
}

/** Marks cards that can be edited while Caregiver Mode is on. */
@Composable
fun EditBadge(modifier: Modifier = Modifier) {
    Icon(
        Icons.Filled.Edit,
        contentDescription = null,
        tint = Color.White,
        modifier = modifier
            .size(30.dp)
            .background(RecordRed.copy(alpha = 0.9f), CircleShape)
            .padding(6.dp),
    )
}

/** Large rounded action with icon + label (listen, call, next…). */
@Composable
fun ActionPill(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = if (enabled) color else color.copy(alpha = 0.35f),
        contentColor = Color.White,
        shadowElevation = if (enabled) 4.dp else 0.dp,
        modifier = modifier
            .heightIn(min = 56.dp)
            .then(if (enabled) Modifier.bounceClick(onClick = onClick) else Modifier),
    ) {
        Row(
            Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(8.dp))
            Text(label, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
