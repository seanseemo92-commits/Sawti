package com.mywords.presentation.navigation

import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mywords.R
import com.mywords.presentation.category.CategoryScreen
import com.mywords.presentation.category.LibraryViewModel
import com.mywords.presentation.home.HomeScreen
import com.mywords.presentation.practice.PracticeRoute
import com.mywords.presentation.practice.PracticeViewModel
import com.mywords.presentation.theme.CaregiverInk
import com.mywords.presentation.theme.CaregiverTint
import com.mywords.speech.SpeechIssue

private const val HOME = "home"
private const val PRACTICE = "practice"
private const val CATEGORY_PREFIX = "category:"

/** Simple state-based navigation: home grid → category (grid / flashcards), plus the practice game. */
@Composable
fun AppRoot(library: LibraryViewModel, practice: PracticeViewModel) {
    val state by library.uiState.collectAsStateWithLifecycle()
    var route by rememberSaveable { mutableStateOf(HOME) }
    val context = LocalContext.current

    val category = if (route.startsWith(CATEGORY_PREFIX)) {
        state.categories.firstOrNull { it.id == route.removePrefix(CATEGORY_PREFIX) }
    } else null

    BackHandler(enabled = route != HOME) { route = HOME }

    val title = when {
        route == PRACTICE -> stringResource(R.string.practice_title)
        category != null -> category.title
        else -> stringResource(R.string.app_title)
    }

    Scaffold(
        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.background,
        topBar = {
            Column {
                AppTopBar(
                    title = title,
                    showBack = route != HOME,
                    caregiverMode = state.caregiverMode,
                    onBack = { route = HOME },
                    onPractice = { route = PRACTICE },
                    onToggleCaregiver = library::toggleCaregiver,
                )
                if (state.caregiverMode) CaregiverBanner()
                state.speechIssue?.let { issue ->
                    SpeechIssueBanner(issue) {
                        try {
                            context.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
                        } catch (_: ActivityNotFoundException) { /* no installer on this device */ }
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when {
                route == PRACTICE -> PracticeRoute(practice)
                category != null -> CategoryScreen(category, state, library)
                else -> HomeScreen(state.categories) { id -> route = CATEGORY_PREFIX + id }
            }
        }
    }
}

/** Soft amber strip – the only hint that Caregiver Mode is on. */
@Composable
private fun CaregiverBanner() {
    Surface(
        color = CaregiverTint,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(
            stringResource(R.string.caregiver_banner),
            color = CaregiverInk,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        )
    }
}

@Composable
private fun SpeechIssueBanner(issue: SpeechIssue, onInstall: () -> Unit) {
    Surface(
        color = Color(0xFFFFE0B2),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Row(
            Modifier.padding(start = 14.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                stringResource(
                    if (issue is SpeechIssue.MissingArabicVoice) R.string.voice_missing else R.string.tts_unavailable
                ),
                color = Color(0xFF5D3A00),
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            if (issue is SpeechIssue.MissingArabicVoice) {
                Button(onClick = onInstall, modifier = Modifier.heightIn(min = 44.dp)) {
                    Text(stringResource(R.string.install_voice))
                }
            }
        }
    }
}
