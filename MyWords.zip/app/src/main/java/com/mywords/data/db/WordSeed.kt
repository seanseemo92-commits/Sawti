package com.mywords.data.db

import com.mywords.domain.model.CategoryIds
import com.mywords.domain.model.PhonemicCue

/**
 * Built-in vocabulary. For every word:
 *   display = friendly on-screen label, tts = fully vocalised MSA for Android TTS,
 *   cue     = first-syllable prompt (derived from tts unless overridden).
 * Edit any of it later from Caregiver Mode.
 */
object WordSeed {

    data class Word(
        val display: String,
        val tts: String,
        val emoji: String = "",
        val subgroup: String = "",
        val cue: String? = null,
        val sort: Int? = null,
    )

    data class Cat(
        val id: String,
        val title: String,
        val palette: Int,
        val words: List<Word>,
        val previewOnTap: Boolean = false,
    )

    private const val HUSBAND = "الزوج"
    private const val CHILDREN = "الأبناء"
    private const val SISTERS = "الأخوات"
    private const val BROTHERS = "الإخوة"

    private fun person(sub: String, name: String, tts: String) = Word(name, tts, subgroup = sub)

    val categories: List<Cat> = listOf(
        // ---- Priority 1: family (the 21 members) ----
        Cat(
            id = CategoryIds.FAMILY, title = "عائلتي", palette = 0, previewOnTap = true,
            words = listOf(
                person(HUSBAND, "محمد", "مُحَمَّدْ"),
                person(CHILDREN, "إيمان", "إِيمَانْ"),
                person(CHILDREN, "خولة", "خَوْلَة"),
                person(CHILDREN, "إبراهيم", "إِبْرَاهِيمْ"),
                person(CHILDREN, "إسماعيل", "إِسْمَاعِيلْ"),
                person(CHILDREN, "أيوب", "أَيُّوبْ"),
                person(CHILDREN, "زكريا", "زَكَرِيَّا"),
                person(CHILDREN, "يوسف", "يُوسُفْ"),
                person(SISTERS, "جمعية", "جُمْعِيَّة"),
                person(SISTERS, "نجاة", "نَجَاة"),
                person(SISTERS, "ربيعة", "رَبِيعَة"),
                person(SISTERS, "سعاد", "سُعَادْ"),
                person(SISTERS, "زينب", "زَيْنَبْ"),
                person(BROTHERS, "الشارف", "الشَّارِفْ"),
                person(BROTHERS, "عياد", "عَيَّادْ"),
                person(BROTHERS, "عبد السلام", "عَبْدُ السَّلَامْ"),
                person(BROTHERS, "خالد", "خَالِدْ"),
                person(BROTHERS, "سعد", "سَعْدْ"),
                person(BROTHERS, "نوري", "نُورِي"),
                person(BROTHERS, "عادل", "عَادِلْ"),
                person(BROTHERS, "وليد", "وَلِيدْ"),
                // second phrase for the husband; sorted last so it stays out of the home-card collage
                Word("وين محمد؟", "أَيْنَ مُحَمَّدْ؟", emoji = "❓", subgroup = HUSBAND, sort = 100),
            ),
        ),
        // ---- Priority 2: daily expressions ----
        Cat(
            id = CategoryIds.DAILY, title = "طلباتي اليومية", palette = 1,
            words = listOf(
                Word("نبي مية", "أُرِيدُ مَاءً", "💧", cue = "مَـ..."),
                Word("نبي شاي", "أُرِيدُ شَايًا", "🍵", cue = "شَـ..."),
                Word("نبي نرتاح", "أُرِيدُ أَنْ أَرْتَاحَ", "🛋️", cue = "أَرْـ..."),
                Word("نبي دوايا", "أُرِيدُ دَوَائِي", "💊", cue = "دَـ..."),
                Word("نبي الحمام", "أُرِيدُ الذَّهَابَ إِلَى الحَمَّامِ", "🚿", cue = "حَمْـ..."),
                Word("عدّل لي المخدة", "أَرْجُو تَعْدِيلَ الوِسَادَةِ", "🛏️", cue = "تَعْـ..."),
            ),
        ),
        // ---- Educational categories (20-25 everyday words each) ----
        Cat(
            id = "vegetables", title = "الخضروات", palette = 3,
            words = listOf(
                Word("طماطم", "طَمَاطِم", "🍅"), Word("بطاطا", "بَطَاطَا", "🥔"),
                Word("بصل", "بَصَل", "🧅"), Word("ثوم", "ثُوم", "🧄"),
                Word("جزر", "جَزَر", "🥕"), Word("خيار", "خِيَار", "🥒"),
                Word("فلفل", "فُلْفُل", "🌶️"), Word("باذنجان", "بَاذِنْجَان", "🍆"),
                Word("كوسة", "كُوسَة", "🥒"), Word("خس", "خَسّ", "🥗"),
                Word("معدنوس / بقدونس", "مَعْدَنُوس", "🌿"), Word("كزبرة", "كُزْبَرَة", "🌱"),
                Word("ليمون", "لِيمُون", "🍋"), Word("بازلاء", "بَازِلَّاء", "🟢"),
                Word("فاصوليا", "فَاصُولِيَا", "🫘"), Word("سبانخ", "سَبَانِخ", "🥬"),
                Word("قرنبيط", "قُرْنَبِيط", "🌼"), Word("بروكلي", "بُرُوكْلِي", "🥦"),
                Word("فجل", "فُجْل", "🌸"), Word("بقطين / قرع", "بَقْطِين", "🎃"),
                Word("نعناع", "نَعْنَاع", "🍃"), Word("ذرة", "ذُرَة", "🌽"),
            ),
        ),
        Cat(
            id = "fruits", title = "الفواكه", palette = 2,
            words = listOf(
                Word("تفاح", "تُفَّاح", "🍎"), Word("موز", "مَوْز", "🍌"),
                Word("برتقال", "بُرْتُقَال", "🍊"), Word("عنب", "عِنَب", "🍇"),
                Word("فراولة", "فَرَاوْلَة", "🍓"), Word("مانجو", "مَانْجُو", "🥭"),
                Word("دلاع (بطيخ)", "دَلَّاع", "🍉"), Word("قلعاوي (شمام)", "قَلْعَاوِي", "🍈"),
                Word("خوخ", "خَوْخ", "🍑"), Word("مشمش", "مِشْمِش", "🟠"),
                Word("إجاص (كمثرى)", "إِجَّاص", "🍐"), Word("رمان", "رُمَّان", "🔴"),
                Word("كرموس (تين)", "كَرْمُوس", "🟣"), Word("تمر", "تَمْر", "🌴"),
                Word("أناناس", "أَنَانَاس", "🍍"), Word("كيوي", "كِيوِي", "🥝"),
                Word("كرز", "كَرَز", "🍒"), Word("توت", "تُوت", "🫐"),
                Word("يوسفي (مندرين)", "يُوسُفِي", "🧡"), Word("أفوكادو", "أَفُوكَادُو", "🥑"),
                Word("جوز الهند", "جَوْزُ الهِنْد", "🥥"),
            ),
        ),
        Cat(
            id = "food", title = "الطعام والشراب", palette = 4,
            words = listOf(
                Word("خبز", "خُبْز", "🍞"), Word("حليب", "حَلِيب", "🥛"),
                Word("بيض", "بَيْض", "🥚"), Word("جبن", "جُبْن", "🧀"),
                Word("زبدة", "زُبْدَة", "🧈"), Word("أرز", "أَرُزّ", "🍚"),
                Word("مكرونة", "مَكَرُونَة", "🍝"), Word("شوربة (حساء)", "شُورْبَة", "🍲"),
                Word("لحم", "لَحْم", "🥩"), Word("دجاج", "دَجَاج", "🍗"),
                Word("سمك", "سَمَك", "🐟"), Word("زيتون", "زَيْتُون", "🫒"),
                Word("زيت", "زَيْت", "🫗"), Word("شاي", "شَاي", "🍵"),
                Word("قهوة", "قَهْوَة", "☕"), Word("عصير", "عَصِير", "🧃"),
                Word("ماء", "مَاء", "💧"), Word("عسل", "عَسَل", "🍯"),
                Word("بسكويت (كعك)", "بِسْكُوِيت", "🍪"), Word("ملح", "مِلْح", "🧂"),
                Word("سكر", "سُكَّر", "🍬"), Word("كعكة", "كَعْكَة", "🍰"),
            ),
        ),
        Cat(
            id = "home", title = "المنزل والأثاث", palette = 6,
            words = listOf(
                Word("سرير", "سَرِير", "🛏️"), Word("مخدة", "مِخَدَّة", "🛌"),
                Word("بطانية", "بَطَّانِيَّة", "🧶"), Word("طاولة", "طَاوِلَة", "🟫"),
                Word("كرسي", "كُرْسِيّ", "🪑"), Word("كنبة (صالون)", "كَنَبَة", "🛋️"),
                Word("باب", "بَاب", "🚪"), Word("نافذة", "نَافِذَة", "🪟"),
                Word("تلفزيون", "تِلِفِزْيُون", "📺"), Word("ثلاجة", "ثَلَّاجَة", "🧊"),
                Word("غسالة", "غَسَّالَة", "🧺"), Word("فرن (غاز)", "فُرْن", "🔥"),
                Word("مكيف", "مُكَيِّف", "❄️"), Word("مروحة", "مِرْوَحَة", "🌀"),
                Word("دولاب", "دُولَاب", "🗄️"), Word("مفتاح", "مِفْتَاح", "🔑"),
                Word("ساعة", "سَاعَة", "⏰"), Word("سجادة", "سَجَّادَة", "🟥"),
                Word("طاسة (كأس)", "طَاسَة", "🥃"), Word("صحن", "صَحْن", "🍽️"),
                Word("ملعقة", "مِلْعَقَة", "🥄"), Word("شوكة", "شَوْكَة", "🍴"),
                Word("سكين", "سِكِّين", "🔪"),
            ),
        ),
        Cat(
            id = "clothes", title = "الملابس", palette = 5,
            words = listOf(
                Word("قميص", "قَمِيص", "👕"), Word("بنطلون", "بَنْطَلُون", "👖"),
                Word("فستان", "فُسْتَان", "👗"), Word("عباية", "عَبَايَة", "👘"),
                Word("حجاب", "حِجَاب", "🧕"), Word("وشاح", "وِشَاح", "🧣"),
                Word("حذاء", "حِذَاء", "👟"), Word("جوارب", "جَوَارِب", "🧦"),
                Word("جاكيت (كوت)", "جَاكِيت", "🧥"), Word("نظارة", "نَظَّارَة", "👓"),
                Word("قبعة", "قُبَّعَة", "👒"), Word("ساعة يد", "سَاعَةُ يَدْ", "⌚"),
                Word("حقيبة", "حَقِيبَة", "👜"), Word("قفازات", "قُفَّازَات", "🧤"),
                Word("خاتم", "خَاتَم", "💍"), Word("قلادة", "قِلَادَة", "📿"),
                Word("صندل", "صَنْدَل", "🩴"), Word("حذاء بكعب", "حِذَاءُ كَعْب", "👠"),
                Word("ربطة عنق", "رَبْطَةُ عُنُقْ", "👔"), Word("بيجامة", "بِيجَامَة", "🩳"),
            ),
        ),
        Cat(
            id = "body", title = "أجزاء الجسم", palette = 9,
            words = listOf(
                Word("عين", "عَيْن", "👁️"), Word("أنف", "أَنْف", "👃"),
                Word("فم", "فَم", "👄"), Word("لسان", "لِسَان", "👅"),
                Word("أذن", "أُذُن", "👂"), Word("يد", "يَد", "✋"),
                Word("قدم (رجل)", "قَدَم", "🦶"), Word("رأس", "رَأْس", "🙂"),
                Word("شعر", "شَعْر", "🦱"), Word("ظهر", "ظَهْر"),
                Word("بطن", "بَطْن"), Word("ركبة", "رُكْبَة", "🦵"),
                Word("أصبع", "إِصْبَع", "☝️"), Word("رقبة", "رَقَبَة"),
                Word("صدر", "صَدْر"), Word("وجه", "وَجْه", "😊"),
                Word("ذراع", "ذِرَاع", "💪"), Word("سن", "سِنّ", "🦷"),
                Word("قلب", "قَلْب", "❤️"), Word("ظفر", "ظُفْر", "💅"),
                Word("كتف", "كَتِف"), Word("حاجب", "حَاجِب", "🤨"),
            ),
        ),
        Cat(
            id = "actions", title = "الأفعال اليومية", palette = 7,
            words = listOf(
                Word("أكل", "أَكْل", "😋"), Word("شرب", "شُرْب", "🥤"),
                Word("نوم", "نَوْم", "😴"), Word("جلوس", "جُلُوس", "🪑"),
                Word("مشي", "مَشْي", "🚶"), Word("وقوف", "وُقُوف", "🧍"),
                Word("غسل", "غَسْل", "🧼"), Word("كلام", "كَلَام", "🗣️"),
                Word("سمع", "سَمْع", "🎧"), Word("فتح", "فَتْح", "🔓"),
                Word("قفل", "قَفْل", "🔒"), Word("قراءة", "قِرَاءَة", "📖"),
                Word("كتابة", "كِتَابَة", "✍️"), Word("ضحك", "ضَحِك", "😄"),
                Word("نظر", "نَظَر", "👀"), Word("لبس", "لُبْس", "👚"),
                Word("طبخ", "طَبْخ", "🍳"), Word("كنس", "كَنْس", "🧹"),
                Word("صلاة", "صَلَاة", "🤲"), Word("استحمام", "اِسْتِحْمَام", "🚿"),
                Word("تصفيق", "تَصْفِيق", "👏"), Word("عناق", "عِنَاق", "🤗"),
            ),
        ),
        Cat(
            id = "animals", title = "الحيوانات والطيور", palette = 8,
            words = listOf(
                Word("قطة", "قِطَّة", "🐱"), Word("كلب", "كَلْب", "🐶"),
                Word("خروف", "خَرُوف", "🐑"), Word("حصان", "حِصَان", "🐴"),
                Word("بقرة", "بَقَرَة", "🐄"), Word("عصفور", "عُصْفُور", "🐦"),
                Word("حمامة", "حَمَامَة", "🕊️"), Word("دجاجة", "دَجَاجَة", "🐔"),
                Word("بطة", "بَطَّة", "🦆"), Word("جمل", "جَمَل", "🐪"),
                Word("ديك", "دِيك", "🐓"), Word("أرنب", "أَرْنَب", "🐰"),
                Word("ماعز", "مَاعِز", "🐐"), Word("أسد", "أَسَد", "🦁"),
                Word("فيل", "فِيل", "🐘"), Word("زرافة", "زَرَافَة", "🦒"),
                Word("قرد", "قِرْد", "🐵"), Word("نسر", "نَسْر", "🦅"),
                Word("ببغاء", "بَبَّغَاء", "🦜"), Word("فراشة", "فَرَاشَة", "🦋"),
                Word("نحلة", "نَحْلَة", "🐝"), Word("سلحفاة", "سُلَحْفَاة", "🐢"),
            ),
        ),
    )

    /** Bump when the built-in vocabulary changes; existing installs are topped up once per version. */
    const val VERSION = 3

    fun categoryEntities(): List<CategoryEntity> =
        categories.mapIndexed { i, c -> CategoryEntity(c.id, c.title, c.palette, c.previewOnTap, i) }

    fun itemEntities(): List<WordItemEntity> =
        categories.flatMap { c ->
            c.words.mapIndexed { i, w ->
                WordItemEntity(
                    categoryId = c.id,
                    subgroup = w.subgroup,
                    displayText = w.display,
                    ttsPrompt = w.tts,
                    phonemicCue = w.cue ?: PhonemicCue.derive(w.tts),
                    emoji = w.emoji,
                    sortOrder = w.sort ?: i,
                )
            }
        }
}
