package com.mywords.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * v2 replaces the v1 tables (family_members, voice_recordings, pain_reports) with the
 * unified categories + word_items schema. Upgrading over v1 recreates the database and the
 * seed is inserted again (photos/phones entered on a v1 install must be re-entered).
 */
@Database(
    entities = [CategoryEntity::class, WordItemEntity::class],
    version = 2,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "my_words.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
