package com.mywords.data

import android.content.Context
import android.graphics.BitmapFactory
import androidx.room.withTransaction
import com.mywords.data.db.AppDatabase
import com.mywords.data.db.SeedExtras
import com.mywords.data.db.WordItemEntity
import com.mywords.data.db.WordSeed
import com.mywords.data.db.toDomain
import com.mywords.domain.model.Category
import com.mywords.domain.model.CategoryIds
import com.mywords.domain.model.TtsEndings
import com.mywords.domain.repository.WordRepository
import java.io.File
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext

class RoomWordRepository(
    private val db: AppDatabase,
    context: Context,
) : WordRepository {

    private val dao = db.wordDao()
    private val filesDir = context.applicationContext.filesDir
    private val prefs = context.applicationContext.getSharedPreferences("seed", Context.MODE_PRIVATE)

    override fun observeCategories(): Flow<List<Category>> =
        combine(dao.observeCategories(), dao.observeItems()) { categories, items ->
            val byCategory = items.groupBy { it.categoryId }
            categories.map { c ->
                Category(
                    id = c.id,
                    title = c.title,
                    palette = c.palette,
                    previewOnTap = c.previewOnTap,
                    items = byCategory[c.id].orEmpty().map { it.toDomain() },
                )
            }
        }

    override suspend fun seedOrUpdateDefaults() {
        if (dao.categoryCount() == 0) {
            db.withTransaction {
                dao.insertCategories(WordSeed.categoryEntities())
                dao.insertItems(WordSeed.itemEntities())
            }
            prefs.edit().putInt(KEY_SEED_VERSION, WordSeed.VERSION).apply()
        } else {
            val previous = prefs.getInt(KEY_SEED_VERSION, 0)
            if (previous < WordSeed.VERSION) {
                topUpSeed(previous)
                prefs.edit().putInt(KEY_SEED_VERSION, WordSeed.VERSION).apply()
            }
        }
    }

    /**
     * Brings an existing install up to the current vocabulary without touching user data:
     * photos, recordings, phone numbers and favourites are never deleted. New words are added,
     * missing sentence prompts are filled in (never overwriting an edited one), and old built-in
     * words that were never customised and are no longer in the list are removed.
     * Default favourites are applied only by the update that introduces them. Runs once per version.
     */
    private suspend fun topUpSeed(previousVersion: Int) {
        db.withTransaction {
            val seedCategories = WordSeed.categoryEntities()
            val existingCategories = dao.categoryIds().toSet()
            dao.insertCategories(seedCategories.filter { it.id !in existingCategories })
            seedCategories.filter { it.id in existingCategories }
                .forEach { dao.updateCategory(it.id, it.title, it.palette, it.previewOnTap, it.sortOrder) }

            val seedItems = WordSeed.itemEntities()
            // 1. old default words that now have a Libyan name are renamed in place (photo/audio/phone kept)
            for ((category, oldName, newName) in WordSeed.renames) {
                val target = seedItems.firstOrNull { it.categoryId == category && it.displayText == newName } ?: continue
                val current = dao.itemKeys()
                val alreadyThere = current.any { it.categoryId == category && it.displayText == newName }
                val old = current.firstOrNull { it.categoryId == category && it.displayText == oldName }
                if (!alreadyThere && old != null) {
                    dao.renameItem(old.id, target.displayText, target.ttsPrompt, target.phonemicCue, target.sentencePrompt)
                }
            }
            val existing = dao.itemKeys()

            // Never delete unmatched rows automatically: a caregiver may have renamed or created
            // vocabulary without attaching media. Seed updates only add/update known defaults.
            existing.forEach { e ->
                val fixed = TtsEndings.normalize(e.ttsPrompt)
                if (fixed != e.ttsPrompt) dao.updateTts(e.id, fixed)
            }

            val kept = existing.associateBy { it.categoryId to it.displayText }
            val applyFavorites = previousVersion < SeedExtras.FAVORITES_SINCE_VERSION
            val missing = mutableListOf<WordItemEntity>()
            for (item in seedItems) {
                val match = kept[item.categoryId to item.displayText]
                if (match == null) {
                    missing += if (applyFavorites) item else item.copy(isFavorite = false)
                } else {
                    dao.updateSort(match.id, item.sortOrder)
                    // words migrated from the first app version only have the plain name as TTS text
                    if (match.ttsPrompt == match.displayText && item.ttsPrompt != match.ttsPrompt) {
                        dao.updateTtsAndCue(match.id, item.ttsPrompt, item.phonemicCue)
                    }
                    item.sentencePrompt?.let { dao.fillSentencePrompt(match.id, it) }
                    if (applyFavorites && item.isFavorite) dao.setFavorite(match.id, true)
                }
            }
            if (missing.isNotEmpty()) dao.insertItems(missing)
        }
    }

    override suspend fun updateDetails(
        id: Long, displayText: String, ttsPrompt: String, phonemicCue: String,
        sentencePrompt: String?, phone: String,
    ) {
        dao.updateDetails(id, displayText, ttsPrompt, phonemicCue, sentencePrompt, phone)
    }

    override suspend fun setFavorite(id: Long, favorite: Boolean) {
        dao.setFavorite(id, favorite)
    }

    /** Copies a picked image into app storage before switching the database reference. */
    override suspend fun setPhoto(id: Long, image: InputStream) {
        withContext(Dispatchers.IO) {
            val dir = File(filesDir, "photos").apply {
                check(isDirectory || mkdirs()) { "Unable to create photo directory" }
            }
            val temp = File.createTempFile("word_${id}_", ".tmp", dir)
            var target: File? = null
            var committed = false
            try {
                image.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
                check(temp.length() > 0L && temp.length() <= MAX_PHOTO_BYTES) { "Image is empty or too large" }
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(temp.absolutePath, bounds)
                check(bounds.outWidth > 0 && bounds.outHeight > 0) { "Selected file is not a supported image" }
                val finalized = File(dir, "word_${id}_${System.currentTimeMillis()}.jpg")
                target = finalized
                check(temp.renameTo(finalized)) { "Unable to finalize imported photo" }
                val old = dao.photoPath(id)
                dao.updatePhoto(id, finalized.absolutePath)
                committed = true
                old?.takeIf { it != finalized.absolutePath }?.let { File(it).delete() }
            } finally {
                temp.delete()
                if (!committed) target?.delete()
            }
        }
    }

    override suspend fun clearPhoto(id: Long) {
        withContext(Dispatchers.IO) {
            val old = dao.photoPath(id)
            dao.updatePhoto(id, null)
            old?.let { File(it).delete() }
        }
    }

    /** Stores a validated path before deleting the previous recording. */
    override suspend fun setAudio(id: Long, file: File) {
        withContext(Dispatchers.IO) {
            require(file.isFile && file.length() > 0L) { "Audio file is missing or empty" }
            val old = dao.audioPath(id)
            dao.updateAudio(id, file.absolutePath)
            if (old != null && old != file.absolutePath) File(old).delete()
        }
    }

    /** Copies a picked audio file into app storage and only then switches the DB reference. */
    override suspend fun importAudio(id: Long, input: InputStream, extension: String) {
        withContext(Dispatchers.IO) {
            val safeExtension = extension.lowercase().filter { it.isLetterOrDigit() }.take(8).ifBlank { "audio" }
            val dir = File(filesDir, "custom_audio").apply {
                check(isDirectory || mkdirs()) { "Unable to create audio directory" }
            }
            val temp = File.createTempFile("word_${id}_", ".tmp", dir)
            var target: File? = null
            var committed = false
            try {
                input.use { src -> temp.outputStream().use { output -> src.copyTo(output) } }
                check(temp.length() > 0L && temp.length() <= MAX_AUDIO_BYTES) { "Audio is empty or too large" }
                val finalized = File(dir, "word_${id}_${System.currentTimeMillis()}.$safeExtension")
                target = finalized
                check(temp.renameTo(finalized)) { "Unable to finalize imported audio" }
                val old = dao.audioPath(id)
                dao.updateAudio(id, finalized.absolutePath)
                committed = true
                if (old != null && old != finalized.absolutePath) File(old).delete()
            } finally {
                temp.delete()
                if (!committed) target?.delete()
            }
        }
    }

    override suspend fun clearAudio(id: Long) {
        withContext(Dispatchers.IO) {
            val old = dao.audioPath(id)
            dao.updateAudio(id, null)
            old?.let { File(it).delete() }
        }
    }

    private companion object {
        const val KEY_SEED_VERSION = "seed_version"
        const val MAX_PHOTO_BYTES = 25L * 1024L * 1024L
        const val MAX_AUDIO_BYTES = 30L * 1024L * 1024L
    }
}
