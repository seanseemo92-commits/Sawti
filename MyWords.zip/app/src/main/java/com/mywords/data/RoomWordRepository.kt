package com.mywords.data

import android.content.Context
import androidx.room.withTransaction
import com.mywords.data.db.AppDatabase
import com.mywords.data.db.WordItemEntity
import com.mywords.data.db.WordSeed
import com.mywords.data.db.toDomain
import com.mywords.domain.model.Category
import com.mywords.domain.model.CategoryIds
import com.mywords.domain.repository.WordRepository
import java.io.File
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.withContext

class RoomWordRepository(
    private val db: AppDatabase,
    context: Context,
) : WordRepository {

    private val dao = db.wordDao()
    private val filesDir = context.applicationContext.filesDir
    private val prefs = context.applicationContext.getSharedPreferences("seed", Context.MODE_PRIVATE)

    override fun observeCategories(): Flow<List<Category>> =
        combine(dao.observeCategories(), dao.observeItems()) { categories, items ->
            val byCategory = items.groupBy { it.categoryId }
            categories.map { c ->
                Category(
                    id = c.id,
                    title = c.title,
                    palette = c.palette,
                    previewOnTap = c.previewOnTap,
                    items = byCategory[c.id].orEmpty().map { it.toDomain() },
                )
            }
        }

    override suspend fun ensureSeeded() {
        if (dao.categoryCount() == 0) {
            db.withTransaction {
                dao.insertCategories(WordSeed.categoryEntities())
                dao.insertItems(WordSeed.itemEntities())
            }
            prefs.edit().putInt(KEY_SEED_VERSION, WordSeed.VERSION).apply()
        } else if (prefs.getInt(KEY_SEED_VERSION, 0) < WordSeed.VERSION) {
            topUpSeed()
            prefs.edit().putInt(KEY_SEED_VERSION, WordSeed.VERSION).apply()
        }
    }

    /**
     * Brings an existing install up to the current vocabulary without touching user data:
     * family members, photos, recordings and phone numbers are never deleted, new words are added,
     * and old built-in words that were never customised and are no longer in the list are removed.
     * Runs once per WordSeed.VERSION, so later edits by the caregiver are not undone.
     */
    private suspend fun topUpSeed() {
        db.withTransaction {
            val seedCategories = WordSeed.categoryEntities()
            val existingCategories = dao.categoryIds().toSet()
            dao.insertCategories(seedCategories.filter { it.id !in existingCategories })
            seedCategories.filter { it.id in existingCategories }
                .forEach { dao.updateCategory(it.id, it.title, it.palette, it.previewOnTap, it.sortOrder) }

            val seedItems = WordSeed.itemEntities()
            val seedKeys = seedItems.map { it.categoryId to it.displayText }.toSet()
            val existing = dao.itemKeys()

            val obsolete = existing.filter {
                it.categoryId != CategoryIds.FAMILY &&
                    (it.categoryId to it.displayText) !in seedKeys &&
                    it.photoPath == null && it.audioPath == null
            }
            obsolete.forEach { dao.deleteItem(it.id) }

            val kept = existing.filter { e -> obsolete.none { it.id == e.id } }
                .associateBy { it.categoryId to it.displayText }
            val missing = mutableListOf<WordItemEntity>()
            for (item in seedItems) {
                val match = kept[item.categoryId to item.displayText]
                if (match != null) dao.updateSort(match.id, item.sortOrder) else missing += item
            }
            if (missing.isNotEmpty()) dao.insertItems(missing)
        }
    }

    override suspend fun updateDetails(id: Long, displayText: String, ttsPrompt: String, phonemicCue: String, phone: String) {
        dao.updateDetails(id, displayText, ttsPrompt, phonemicCue, phone)
    }

    /** Copies the picked image into app storage so it survives even if the gallery item moves. */
    override suspend fun setPhoto(id: Long, image: InputStream) {
        withContext(Dispatchers.IO) {
            val dir = File(filesDir, "photos").apply { mkdirs() }
            val target = File(dir, "word_${id}_${System.currentTimeMillis()}.jpg")
            image.use { input -> target.outputStream().use { input.copyTo(it) } }
            val old = dao.photoPath(id)
            dao.updatePhoto(id, target.absolutePath)
            old?.let { File(it).delete() }
        }
    }

    override suspend fun clearPhoto(id: Long) {
        withContext(Dispatchers.IO) {
            dao.photoPath(id)?.let { File(it).delete() }
            dao.updatePhoto(id, null)
        }
    }

    override suspend fun setAudio(id: Long, file: File) {
        withContext(Dispatchers.IO) {
            val old = dao.audioPath(id)
            dao.updateAudio(id, file.absolutePath)
            if (old != null && old != file.absolutePath) File(old).delete()
        }
    }

    override suspend fun clearAudio(id: Long) {
        withContext(Dispatchers.IO) {
            dao.audioPath(id)?.let { File(it).delete() }
            dao.updateAudio(id, null)
        }
    }

    private companion object {
        const val KEY_SEED_VERSION = "seed_version"
    }
}
