package com.mywords.domain.repository

import com.mywords.domain.model.Category
import java.io.File
import java.io.InputStream
import kotlinx.coroutines.flow.Flow

interface WordRepository {
    /** Categories in display order, each with its items. */
    fun observeCategories(): Flow<List<Category>>

    /** Inserts the built-in vocabulary the first time the app runs. */
    suspend fun ensureSeeded()

    suspend fun updateDetails(id: Long, displayText: String, ttsPrompt: String, phonemicCue: String, phone: String)
    suspend fun setPhoto(id: Long, image: InputStream)
    suspend fun clearPhoto(id: Long)
    suspend fun setAudio(id: Long, file: File)
    suspend fun clearAudio(id: Long)
}
