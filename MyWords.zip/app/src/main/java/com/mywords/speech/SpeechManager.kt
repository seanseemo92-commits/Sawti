package com.mywords.speech

import android.content.Context
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Problems the UI surfaces so a caregiver can fix them. */
sealed interface SpeechIssue {
    data object EngineUnavailable : SpeechIssue
    data object MissingArabicVoice : SpeechIssue
}

/**
 * Arabic text-to-speech (Locale "ar", rate 0.85). Fully vocalised prompts (tashkeel)
 * are sent as-is so the engine does not guess vowels or spell words out.
 */
class SpeechManager(context: Context) : TextToSpeech.OnInitListener {

    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var arabicReady = false
    private var pending: (() -> Unit)? = null

    private val _issue = MutableStateFlow<SpeechIssue?>(null)
    val issue: StateFlow<SpeechIssue?> = _issue.asStateFlow()

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            _issue.value = SpeechIssue.EngineUnavailable
            return
        }
        tts.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA) // hardware volume keys control loudness
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        tts.setSpeechRate(0.85f)
        ready = true
        pending?.invoke()
        pending = null
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        val action = { speakNow(text) }
        if (ready) action() else pending = action
    }

    fun stop() {
        pending = null
        tts.stop()
    }

    private fun speakNow(text: String) {
        if (!ensureArabic()) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mw-${System.nanoTime()}")
    }

    private fun ensureArabic(): Boolean {
        if (arabicReady) return true
        for (tag in listOf("ar", "ar-SA", "ar-EG")) {
            val result = tts.setLanguage(Locale.forLanguageTag(tag))
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                arabicReady = true
                _issue.value = null
                return true
            }
        }
        _issue.value = SpeechIssue.MissingArabicVoice
        return false
    }
}
