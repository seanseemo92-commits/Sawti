package com.mywords.audio

import android.media.AudioAttributes
import android.media.MediaPlayer

/** Plays caregiver recordings. One clip at a time. */
class AudioPlayer {
    private var player: MediaPlayer? = null

    fun play(path: String, onDone: () -> Unit = {}) {
        stop()
        player = runCatching {
            MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                setDataSource(path)
                setOnCompletionListener { stop(); onDone() }
                setOnErrorListener { _, _, _ -> stop(); onDone(); true }
                prepare()
                start()
            }
        }.getOrNull()
    }

    fun stop() {
        player?.runCatching { stop(); release() }
        player = null
    }
}
