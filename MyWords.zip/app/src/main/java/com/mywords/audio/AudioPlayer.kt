package com.mywords.audio

import android.media.AudioAttributes
import android.media.MediaPlayer

/** Plays caregiver recordings / imported audio files asynchronously. One clip at a time. */
class AudioPlayer {
    private var player: MediaPlayer? = null

    /** Returns false only if player setup fails synchronously. */
    fun play(path: String, onDone: () -> Unit = {}, onFailure: (() -> Unit)? = null): Boolean {
        stop()
        val mp = MediaPlayer()
        player = mp
        return try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(path)
            mp.setOnPreparedListener { prepared ->
                if (player === prepared) runCatching { prepared.start() }.onFailure {
                    if (releaseIfCurrent(prepared)) (onFailure ?: onDone).invoke()
                }
                else runCatching { prepared.release() }
            }
            mp.setOnCompletionListener { completed ->
                if (releaseIfCurrent(completed)) onDone()
            }
            mp.setOnErrorListener { failed, _, _ ->
                if (releaseIfCurrent(failed)) (onFailure ?: onDone).invoke()
                true
            }
            mp.prepareAsync()
            true
        } catch (_: Exception) {
            releaseIfCurrent(mp)
            false
        }
    }

    private fun releaseIfCurrent(mp: MediaPlayer): Boolean {
        val wasCurrent = player === mp
        if (wasCurrent) player = null
        runCatching { mp.release() }
        return wasCurrent
    }

    fun stop() {
        val current = player
        player = null
        if (current != null) {
            runCatching { if (current.isPlaying) current.stop() }
            runCatching { current.release() }
        }
    }
}
