package com.mywords.audio

import com.mywords.domain.model.PhonemicCue
import com.mywords.domain.model.WordItem
import com.mywords.speech.SpeechManager
import java.io.File

/** The dual audio engine: caregiver recording first, Arabic TTS as the fallback. */
class WordVoice(
    private val speech: SpeechManager,
    private val player: AudioPlayer,
) {
    /** Main tap: custom recording if present, otherwise the vocalised ttsPrompt. */
    fun play(item: WordItem) {
        val recording = item.audioPath?.takeIf { File(it).exists() }
        if (recording != null) {
            speech.stop()
            player.play(recording)
        } else {
            player.stop()
            speech.speak(item.ttsPrompt)
        }
    }

    /** 💡 button: only the first syllable, so she can try to finish the word herself. */
    fun hint(item: WordItem) {
        val cue = item.phonemicCue.ifBlank { PhonemicCue.derive(item.ttsPrompt) }
        player.stop()
        speech.speak(PhonemicCue.forSpeech(cue))
    }

    fun stop() {
        speech.stop()
        player.stop()
    }
}
